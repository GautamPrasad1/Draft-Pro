export type ToolMode = 'select' | 'balloon' | 'pan' | 'stamp' | 'box';

export type BalloonShape = 'circle' | 'square' | 'hexagon' | 'diamond' | 'split';

export type PointerStyle = 'wedge' | 'arrow' | 'none';

export type PointerPreset =
  | 'teardrop'
  | 'arrow'
  | 'circle'
  | 'square'
  | 'hexagon'
  | 'diamond'
  | 'split';

export const POINTER_PRESETS: {
  value: PointerPreset;
  label: string;
  shape: BalloonShape;
  pointerStyle: PointerStyle;
}[] = [
  { value: 'teardrop', label: 'Teardrop', shape: 'circle', pointerStyle: 'wedge' },
  { value: 'arrow', label: 'Arrow', shape: 'circle', pointerStyle: 'arrow' },
  { value: 'circle', label: 'Circle', shape: 'circle', pointerStyle: 'none' },
  { value: 'square', label: 'Square', shape: 'square', pointerStyle: 'none' },
  { value: 'hexagon', label: 'Hexagon', shape: 'hexagon', pointerStyle: 'none' },
  { value: 'diamond', label: 'Diamond', shape: 'diamond', pointerStyle: 'none' },
  { value: 'split', label: 'Split', shape: 'split', pointerStyle: 'none' },
];

export function styleToPointerPreset(style: Pick<BalloonStyle, 'shape' | 'pointerStyle'>): PointerPreset {
  if (style.shape === 'circle' && style.pointerStyle === 'wedge') return 'teardrop';
  if (style.shape === 'circle' && style.pointerStyle === 'arrow') return 'arrow';
  if (style.shape === 'square') return 'square';
  if (style.shape === 'hexagon') return 'hexagon';
  if (style.shape === 'diamond') return 'diamond';
  if (style.shape === 'split') return 'split';
  return 'circle';
}

export function pointerPresetToStylePatch(
  preset: PointerPreset
): Pick<BalloonStyle, 'shape' | 'pointerStyle'> {
  const found = POINTER_PRESETS.find((p) => p.value === preset) ?? POINTER_PRESETS[0];
  return { shape: found.shape, pointerStyle: found.pointerStyle };
}

export type CharacteristicType =
  | 'Dimension'
  | 'GD&T'
  | 'Note'
  | 'Surface Finish'
  | 'Material'
  | 'Weld'
  | 'Hole / Thread'
  | 'Other';

export type Criticality = 'Standard' | 'Major' | 'Critical';

export type InspectionStatus = '' | 'OK' | 'NOT OK';

export interface InspectionReportMeta {
  companyName: string;
  reportTitle: string;
  docNo: string;
  issueNo: string;
  revNo: string;
  effDate: string;
  partName: string;
  partNumberRev: string;
  plantCode: string;
  pageLabel: string;
  vendorName: string;
  invoiceNo: string;
  qty: string;
  date: string;
  inspectedBy: string;
  checkedBy: string;
  approvedBy: string;
}

export const DEFAULT_REPORT_META: InspectionReportMeta = {
  companyName: 'YOUR COMPANY NAME',
  reportTitle: 'SAMPLE INSPECTION REPORT',
  docNo: '',
  issueNo: '',
  revNo: '',
  effDate: '',
  partName: '',
  partNumberRev: '',
  plantCode: '',
  pageLabel: '1 OF 1',
  vendorName: '',
  invoiceNo: '',
  qty: '',
  date: '',
  inspectedBy: '',
  checkedBy: '',
  approvedBy: '',
};

export interface BalloonStyle {
  shape: BalloonShape;
  pointerStyle: PointerStyle;
  color: string;
  fillColor: string;
  transparentFill: boolean;
  radius: number;
  strokeWidth: number;
  fontScale: number;
}

export interface BalloonItem {
  id: string;
  pageIndex: number;
  label: string;
  subLabel: string;
  /** Balloon center X in native drawing image coordinates */
  x: number;
  /** Balloon center Y in native drawing image coordinates */
  y: number;
  /** Pointer tip X in native drawing image coordinates */
  targetX: number;
  /** Pointer tip Y in native drawing image coordinates */
  targetY: number;
  style: BalloonStyle;
  description: string;
  nominal: string;
  tolerance: string;
  inspectionMethod: string;
  samples: [string, string, string, string, string];
  status: InspectionStatus;
  type: CharacteristicType;
  zone: string;
  criticality: Criticality;
  remarks: string;
}

export interface StampAnnotation {
  id: string;
  kind: 'stamp';
  pageIndex: number;
  x: number;
  y: number;
  text: string;
  color: string;
  fontSize: number;
  bordered: boolean;
}

export interface BoxAnnotation {
  id: string;
  kind: 'box';
  pageIndex: number;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  strokeWidth: number;
  dashed: boolean;
  label: string;
}

export type DrawingAnnotation = StampAnnotation | BoxAnnotation;

export type AnnotationPatch =
  | Partial<Omit<StampAnnotation, 'id' | 'kind'>>
  | Partial<Omit<BoxAnnotation, 'id' | 'kind'>>;

export interface DrawingPage {
  index: number;
  dataUrl: string;
  width: number;
  height: number;
  rotation: 0 | 90 | 180 | 270;
}

export interface LoadedDocument {
  fileName: string;
  fileType: 'pdf' | 'tiff' | 'image';
  pages: DrawingPage[];
  sourcePdfBytes?: Uint8Array;
}

export interface HistorySnapshot {
  balloons: BalloonItem[];
  annotations: DrawingAnnotation[];
  nextNumber: number;
}

export interface ProjectJSON {
  version: 1;
  fileName: string;
  balloons: BalloonItem[];
  annotations: DrawingAnnotation[];
  nextNumber: number;
  defaultStyle: BalloonStyle;
  reportMeta?: InspectionReportMeta;
}

export const QA_COLORS = [
  { name: 'CAD Blue', value: '#0000FF' },
  { name: 'Cobalt Blue', value: '#1D4ED8' },
  { name: 'Inspection Red', value: '#DC2626' },
  { name: 'Emerald', value: '#15803D' },
  { name: 'Magenta', value: '#A21CAF' },
  { name: 'Charcoal', value: '#0F172A' },
] as const;

export const DEFAULT_BALLOON_STYLE: BalloonStyle = {
  shape: 'circle',
  pointerStyle: 'wedge',
  color: '#0000FF',
  fillColor: '#FFFFFF',
  transparentFill: false,
  radius: 20,
  strokeWidth: 3,
  fontScale: 1,
};
