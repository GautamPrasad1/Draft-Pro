import { useState } from 'react';
import {
  Search,
  Trash2,
  Paintbrush,
  Crosshair,
  ListOrdered,
  Minus,
  Plus,
  FileSpreadsheet,
} from 'lucide-react';
import {
  POINTER_PRESETS,
  QA_COLORS,
  styleToPointerPreset,
  type AnnotationPatch,
  type BalloonItem,
  type BalloonStyle,
  type CharacteristicType,
  type Criticality,
  type DrawingAnnotation,
  type InspectionStatus,
  type PointerPreset,
} from '../types/drawing';

interface InspectorPanelProps {
  balloons: BalloonItem[];
  annotations: DrawingAnnotation[];
  currentPage: number;
  pageCount: number;
  selectedBalloonIds: string[];
  selectedAnnotationId: string | null;
  defaultStyle: BalloonStyle;
  onSelectBalloon: (id: string, opts?: { focus?: boolean; toggle?: boolean }) => void;
  onSelectAllPage: () => void;
  onUpdateBalloon: (id: string, patch: Partial<BalloonItem>) => void;
  onResizeSelectedBalloons: (radius: number) => void;
  onUpdateSelectedBalloonsPreset: (preset: PointerPreset) => void;
  onUpdateSelectedBalloonsColor: (color: string) => void;
  onDeleteSelectedBalloons: () => void;
  onUpdateAnnotation: (id: string, patch: AnnotationPatch) => void;
  onDeleteAnnotation: (id: string) => void;
  onChangeDefaultPreset: (preset: PointerPreset) => void;
  onChangeDefaultStyle: (patch: Partial<BalloonStyle>) => void;
  onApplyStyleToAll: () => void;
  onRenumber: () => void;
  onOpenInspectionSheet: () => void;
}

const CHAR_TYPES: CharacteristicType[] = [
  'Dimension',
  'GD&T',
  'Hole / Thread',
  'Surface Finish',
  'Material',
  'Weld',
  'Note',
  'Other',
];

const CRITICALITIES: Criticality[] = ['Standard', 'Major', 'Critical'];

export function InspectorPanel({
  balloons,
  annotations,
  currentPage,
  pageCount,
  selectedBalloonIds,
  selectedAnnotationId,
  defaultStyle,
  onSelectBalloon,
  onSelectAllPage,
  onUpdateBalloon,
  onResizeSelectedBalloons,
  onUpdateSelectedBalloonsPreset,
  onUpdateSelectedBalloonsColor,
  onDeleteSelectedBalloons,
  onUpdateAnnotation,
  onDeleteAnnotation,
  onChangeDefaultPreset,
  onChangeDefaultStyle,
  onApplyStyleToAll,
  onRenumber,
  onOpenInspectionSheet,
}: InspectorPanelProps) {
  const [tab, setTab] = useState<'list' | 'style'>('list');
  const [search, setSearch] = useState('');
  const [showAllPages, setShowAllPages] = useState(false);

  const selectedSet = new Set(selectedBalloonIds);
  const selectedBalloons = balloons.filter((b) => selectedSet.has(b.id));
  const singleBalloon = selectedBalloons.length === 1 ? selectedBalloons[0] : null;
  const multiSelected = selectedBalloons.length > 1;

  const selectedAnnotation = selectedAnnotationId
    ? annotations.find((a) => a.id === selectedAnnotationId) ?? null
    : null;

  const filteredBalloons = balloons
    .filter((b) => (showAllPages ? true : b.pageIndex === currentPage))
    .filter((b) => {
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        b.label.toLowerCase().includes(q) ||
        b.nominal.toLowerCase().includes(q) ||
        b.type.toLowerCase().includes(q) ||
        b.zone.toLowerCase().includes(q) ||
        b.remarks.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      if (a.pageIndex !== b.pageIndex) return a.pageIndex - b.pageIndex;
      const na = parseFloat(a.label);
      const nb = parseFloat(b.label);
      if (!Number.isNaN(na) && !Number.isNaN(nb) && na !== nb) return na - nb;
      return a.label.localeCompare(b.label);
    });

  const activeDefaultPreset = styleToPointerPreset(defaultStyle);

  return (
    <aside
      aria-label="Inspection Panel"
      className="w-84 bg-white border-l border-slate-200 flex flex-col shrink-0 z-20"
    >
      {/* Tab Switcher */}
      <div className="p-3 border-b border-slate-200">
        <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-lg gap-1">
          <button
            type="button"
            onClick={() => setTab('list')}
            className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              tab === 'list'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Characteristics ({balloons.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('style')}
            className={`py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              tab === 'style'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pointer Style
          </button>
        </div>
      </div>

      {tab === 'list' ? (
        <div className="flex-1 flex flex-col min-h-0">
          {/* Search & Filter Row */}
          <div className="px-3 py-2.5 border-b border-slate-100 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter #, nominal, zone..."
                className="w-full h-8 pl-8 pr-2.5 text-xs bg-slate-50 border border-slate-200 rounded-md text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-blue-600"
              />
            </div>
            {pageCount > 1 ? (
              <button
                type="button"
                onClick={() => setShowAllPages((prev) => !prev)}
                className={`px-2.5 h-8 text-[11px] font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  showAllPages
                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {showAllPages ? 'All Pages' : `P.${currentPage + 1}`}
              </button>
            ) : (
              balloons.length > 0 && (
                <button
                  type="button"
                  onClick={onSelectAllPage}
                  title="Select all pointers (Ctrl+A)"
                  className="px-2.5 h-8 text-[11px] font-medium rounded-md border bg-white text-slate-600 border-slate-200 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  All
                </button>
              )
            )}
          </div>

          {/* Scrollable Characteristic Table */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredBalloons.length === 0 ? (
              <div className="px-5 py-10 text-center">
                <p className="text-xs font-medium text-slate-700 mb-1">
                  {balloons.length === 0
                    ? 'No pointers placed yet'
                    : 'No matching pointers'}
                </p>
                <p className="text-xs text-slate-500 leading-relaxed">
                  {balloons.length === 0
                    ? 'Click anywhere on the drawing to place a Teardrop pointer, or drag from a dimension to aim it.'
                    : 'Try clearing the search filter to view all items.'}
                </p>
              </div>
            ) : (
              filteredBalloons.map((b) => {
                const isSelected = selectedSet.has(b.id);
                return (
                  <div
                    key={b.id}
                    onClick={(e) =>
                      onSelectBalloon(b.id, {
                        focus: !(e.ctrlKey || e.metaKey),
                        toggle: e.ctrlKey || e.metaKey,
                      })
                    }
                    className={`px-3 py-2.5 flex items-center gap-2.5 cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50/80' : 'hover:bg-slate-50'
                    }`}
                  >
                    <span
                      className="w-7 h-7 rounded-full border-2 flex items-center justify-center text-[11px] font-mono tabular-nums font-bold shrink-0 bg-white"
                      style={{ borderColor: b.style.color, color: b.style.color }}
                    >
                      {b.label}
                    </span>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-slate-900 truncate font-mono tabular-nums">
                          {b.nominal.trim() ? b.nominal : `Item #${b.label}`}
                          {b.tolerance.trim() ? ` ${b.tolerance}` : ''}
                        </span>
                        {b.criticality !== 'Standard' && (
                          <span
                            className={`text-[10px] font-semibold shrink-0 ${
                              b.criticality === 'Critical'
                                ? 'text-red-700'
                                : 'text-amber-700'
                            }`}
                          >
                            {b.criticality}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 truncate mt-0.5">
                        <span>{b.type}</span>
                        {b.zone && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span>{b.zone}</span>
                          </>
                        )}
                        {pageCount > 1 && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">
                              P.{b.pageIndex + 1}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      title="Center on drawing"
                      aria-label={`Center on pointer ${b.label}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBalloon(b.id, { focus: true, toggle: false });
                      }}
                      className="p-1 text-slate-400 hover:text-blue-700 rounded cursor-pointer shrink-0"
                    >
                      <Crosshair className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </div>

          {/* Multi-Selection Batch Editor */}
          {multiSelected && (
            <div className="border-t border-slate-200 bg-slate-50/80 p-3.5 space-y-3 shrink-0">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-slate-900">
                  {selectedBalloons.length} Pointers Selected
                </h2>
                <button
                  type="button"
                  onClick={onDeleteSelectedBalloons}
                  className="inline-flex items-center gap-1 text-xs text-red-700 hover:text-red-800 font-medium cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete All</span>
                </button>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-medium text-slate-600">Resize Selected</span>
                  <span className="font-mono tabular-nums text-slate-500">
                    {Math.round(selectedBalloons[0].style.radius)}px
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onResizeSelectedBalloons(
                        Math.max(10, selectedBalloons[0].style.radius - 2)
                      )
                    }
                    className="w-7 h-7 rounded border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                    aria-label="Decrease selected size"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <input
                    type="range"
                    min={10}
                    max={72}
                    step={1}
                    value={selectedBalloons[0].style.radius}
                    onChange={(e) => onResizeSelectedBalloons(Number(e.target.value))}
                    className="flex-1 accent-blue-700 cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      onResizeSelectedBalloons(
                        Math.min(72, selectedBalloons[0].style.radius + 2)
                      )
                    }
                    className="w-7 h-7 rounded border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                    aria-label="Increase selected size"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 items-end">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Pointer Type
                  </span>
                  <select
                    value={styleToPointerPreset(selectedBalloons[0].style)}
                    onChange={(e) =>
                      onUpdateSelectedBalloonsPreset(e.target.value as PointerPreset)
                    }
                    className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  >
                    {POINTER_PRESETS.map((p) => (
                      <option key={p.value} value={p.value}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </label>

                <div>
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Color
                  </span>
                  <div className="flex items-center gap-1.5 h-8">
                    {QA_COLORS.slice(0, 5).map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        onClick={() => onUpdateSelectedBalloonsColor(c.value)}
                        className="w-5 h-5 rounded-full cursor-pointer hover:scale-105 transition-transform"
                        style={{ backgroundColor: c.value }}
                        aria-label={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Single Selected Balloon Detail Editor */}
          {singleBalloon && (
            <div className="border-t border-slate-200 bg-slate-50/70 p-3.5 space-y-3 shrink-0 max-h-[56%] overflow-y-auto">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-slate-900">
                  Pointer #{singleBalloon.label} Details
                </h2>
                <button
                  type="button"
                  onClick={onDeleteSelectedBalloons}
                  className="inline-flex items-center gap-1 text-xs text-red-700 hover:text-red-800 font-medium cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>

              {/* Size Control right inside selected editor */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-medium text-slate-600">Size</span>
                  <span className="font-mono tabular-nums text-slate-500">
                    {Math.round(singleBalloon.style.radius)}px
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onResizeSelectedBalloons(
                        Math.max(10, singleBalloon.style.radius - 2)
                      )
                    }
                    className="w-7 h-7 rounded border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                    aria-label="Decrease size"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <input
                    type="range"
                    min={10}
                    max={72}
                    step={1}
                    value={singleBalloon.style.radius}
                    onChange={(e) => onResizeSelectedBalloons(Number(e.target.value))}
                    className="flex-1 accent-blue-700 cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      onResizeSelectedBalloons(
                        Math.min(72, singleBalloon.style.radius + 2)
                      )
                    }
                    className="w-7 h-7 rounded border border-slate-200 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer shrink-0"
                    aria-label="Increase size"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Pointer #
                  </span>
                  <input
                    type="text"
                    value={singleBalloon.label}
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, { label: e.target.value })
                    }
                    className="w-full h-8 px-2.5 text-xs font-mono font-semibold bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  />
                </label>

                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    {singleBalloon.style.shape === 'split' ? 'Sub-Label' : 'Drawing Zone'}
                  </span>
                  {singleBalloon.style.shape === 'split' ? (
                    <input
                      type="text"
                      value={singleBalloon.subLabel}
                      placeholder="e.g. A"
                      onChange={(e) =>
                        onUpdateBalloon(singleBalloon.id, { subLabel: e.target.value })
                      }
                      className="w-full h-8 px-2.5 text-xs font-mono bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                    />
                  ) : (
                    <input
                      type="text"
                      value={singleBalloon.zone}
                      placeholder="e.g. VIEW A"
                      onChange={(e) =>
                        onUpdateBalloon(singleBalloon.id, { zone: e.target.value })
                      }
                      className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                    />
                  )}
                </label>
              </div>

              <label className="block">
                <span className="block text-[11px] font-medium text-slate-600 mb-1">
                  Description
                </span>
                <input
                  type="text"
                  value={singleBalloon.description}
                  placeholder="e.g. Overall Length, Hole Dia"
                  onChange={(e) =>
                    onUpdateBalloon(singleBalloon.id, { description: e.target.value })
                  }
                  className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                />
              </label>

              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Specification
                  </span>
                  <input
                    type="text"
                    value={singleBalloon.nominal}
                    placeholder="e.g. Ø7 HOLE"
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, { nominal: e.target.value })
                    }
                    className="w-full h-8 px-2.5 text-xs font-mono bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  />
                </label>

                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Tolerance
                  </span>
                  <input
                    type="text"
                    value={singleBalloon.tolerance}
                    placeholder="e.g. ±0.2"
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, { tolerance: e.target.value })
                    }
                    className="w-full h-8 px-2.5 text-xs font-mono bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Inspection Method
                  </span>
                  <input
                    type="text"
                    value={singleBalloon.inspectionMethod}
                    placeholder="Vernier / CMM"
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, {
                        inspectionMethod: e.target.value,
                      })
                    }
                    className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  />
                </label>

                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Status
                  </span>
                  <select
                    value={singleBalloon.status}
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, {
                        status: e.target.value as InspectionStatus,
                      })
                    }
                    className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  >
                    <option value="">Pending</option>
                    <option value="OK">OK</option>
                    <option value="NOT OK">NOT OK</option>
                  </select>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Characteristic
                  </span>
                  <select
                    value={singleBalloon.type}
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, {
                        type: e.target.value as CharacteristicType,
                      })
                    }
                    className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  >
                    {CHAR_TYPES.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Criticality
                  </span>
                  <select
                    value={singleBalloon.criticality}
                    onChange={(e) =>
                      onUpdateBalloon(singleBalloon.id, {
                        criticality: e.target.value as Criticality,
                      })
                    }
                    className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  >
                    {CRITICALITIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Pointer
                  </span>
                  <select
                    value={styleToPointerPreset(singleBalloon.style)}
                    onChange={(e) =>
                      onUpdateSelectedBalloonsPreset(e.target.value as PointerPreset)
                    }
                    className="w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                  >
                    {POINTER_PRESETS.map((p) => (
                      <option key={p.value} value={p.value}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </label>

                <div>
                  <span className="block text-[11px] font-medium text-slate-600 mb-1">
                    Color
                  </span>
                  <div className="flex items-center gap-1.5 h-8">
                    {QA_COLORS.slice(0, 5).map((c) => (
                      <button
                        key={c.value}
                        type="button"
                        onClick={() => onUpdateSelectedBalloonsColor(c.value)}
                        className={`w-5 h-5 rounded-full cursor-pointer ${
                          singleBalloon.style.color.toLowerCase() === c.value.toLowerCase()
                            ? 'ring-2 ring-offset-1 ring-slate-900'
                            : ''
                        }`}
                        style={{ backgroundColor: c.value }}
                        aria-label={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <label className="block">
                <span className="block text-[11px] font-medium text-slate-600 mb-1">
                  Remark
                </span>
                <input
                  type="text"
                  value={singleBalloon.remarks}
                  placeholder="Inspection remark"
                  onChange={(e) =>
                    onUpdateBalloon(singleBalloon.id, { remarks: e.target.value })
                  }
                  className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                />
              </label>
            </div>
          )}

          {!singleBalloon && !multiSelected && !selectedAnnotation && (
            <div className="p-3 border-t border-slate-200 bg-slate-50/70 shrink-0">
              <button
                type="button"
                onClick={onOpenInspectionSheet}
                className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-emerald-800 bg-white border border-emerald-200 rounded-lg hover:bg-emerald-50 transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Open Sample Inspection Report</span>
              </button>
            </div>
          )}

          {/* Selected Annotation (Stamp or Callout Box) Editor */}
          {selectedAnnotation && (
            <div className="border-t border-slate-200 bg-slate-50/70 p-3.5 space-y-3 shrink-0">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-slate-900">
                  {selectedAnnotation.kind === 'stamp'
                    ? 'Revision Stamp'
                    : 'Area Callout Box'}
                </h2>
                <button
                  type="button"
                  onClick={() => onDeleteAnnotation(selectedAnnotation.id)}
                  className="inline-flex items-center gap-1 text-xs text-red-700 hover:text-red-800 font-medium cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>

              {selectedAnnotation.kind === 'stamp' ? (
                <>
                  <label className="block">
                    <span className="block text-[11px] font-medium text-slate-600 mb-1">
                      Stamp Text
                    </span>
                    <textarea
                      rows={2}
                      value={selectedAnnotation.text}
                      onChange={(e) =>
                        onUpdateAnnotation(selectedAnnotation.id, {
                          text: e.target.value,
                        })
                      }
                      className="w-full p-2 text-xs font-semibold bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600 resize-none"
                    />
                  </label>
                  <div className="grid grid-cols-2 gap-2 items-center">
                    <label className="block">
                      <span className="block text-[11px] font-medium text-slate-600 mb-1">
                        Size ({selectedAnnotation.fontSize}px)
                      </span>
                      <input
                        type="range"
                        min={12}
                        max={72}
                        value={selectedAnnotation.fontSize}
                        onChange={(e) =>
                          onUpdateAnnotation(selectedAnnotation.id, {
                            fontSize: Number(e.target.value),
                          })
                        }
                        className="w-full accent-blue-700"
                      />
                    </label>
                    <label className="flex items-center gap-2 text-xs text-slate-700 mt-4 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedAnnotation.bordered}
                        onChange={(e) =>
                          onUpdateAnnotation(selectedAnnotation.id, {
                            bordered: e.target.checked,
                          })
                        }
                        className="rounded accent-blue-700"
                      />
                      <span>Box Border</span>
                    </label>
                  </div>
                </>
              ) : (
                <>
                  <label className="block">
                    <span className="block text-[11px] font-medium text-slate-600 mb-1">
                      Box Label
                    </span>
                    <input
                      type="text"
                      value={selectedAnnotation.label}
                      placeholder="e.g. VIEW B"
                      onChange={(e) =>
                        onUpdateAnnotation(selectedAnnotation.id, {
                          label: e.target.value,
                        })
                      }
                      className="w-full h-8 px-2.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                    />
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="block">
                      <span className="block text-[11px] font-medium text-slate-600 mb-1">
                        Width (px)
                      </span>
                      <input
                        type="number"
                        min={20}
                        value={Math.round(selectedAnnotation.width)}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (v >= 20)
                            onUpdateAnnotation(selectedAnnotation.id, { width: v });
                        }}
                        className="w-full h-8 px-2 text-xs font-mono bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                      />
                    </label>
                    <label className="block">
                      <span className="block text-[11px] font-medium text-slate-600 mb-1">
                        Height (px)
                      </span>
                      <input
                        type="number"
                        min={20}
                        value={Math.round(selectedAnnotation.height)}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (v >= 20)
                            onUpdateAnnotation(selectedAnnotation.id, { height: v });
                        }}
                        className="w-full h-8 px-2 text-xs font-mono bg-white border border-slate-200 rounded-md focus:outline-none focus:border-blue-600"
                      />
                    </label>
                  </div>
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedAnnotation.dashed}
                      onChange={(e) =>
                        onUpdateAnnotation(selectedAnnotation.id, {
                          dashed: e.target.checked,
                        })
                      }
                      className="rounded accent-blue-700"
                    />
                    <span>Dashed Outline</span>
                  </label>
                </>
              )}

              <div className="flex items-center gap-1.5">
                {QA_COLORS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() =>
                      onUpdateAnnotation(selectedAnnotation.id, { color: c.value })
                    }
                    className={`w-5 h-5 rounded-full cursor-pointer ${
                      selectedAnnotation.color.toLowerCase() === c.value.toLowerCase()
                        ? 'ring-2 ring-offset-1 ring-slate-900'
                        : ''
                    }`}
                    style={{ backgroundColor: c.value }}
                    aria-label={c.name}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Unified Pointer Style Configuration Tab */
        <div className="flex-1 overflow-y-auto p-4 space-y-5">
          <div>
            <h3 className="text-xs font-semibold text-slate-900 mb-2.5">
              Pointer &amp; Shape
            </h3>
            <div className="grid grid-cols-2 gap-1.5">
              {POINTER_PRESETS.map((p) => (
                <button
                  key={p.value}
                  type="button"
                  onClick={() => onChangeDefaultPreset(p.value)}
                  className={`py-2 px-2.5 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                    activeDefaultPreset === p.value
                      ? 'bg-blue-50 border-blue-600 text-blue-800'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-slate-900 mb-2.5">
              Ink &amp; Fill Color
            </h3>
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                {QA_COLORS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => onChangeDefaultStyle({ color: c.value })}
                    className={`w-6 h-6 rounded-full cursor-pointer ${
                      defaultStyle.color.toLowerCase() === c.value.toLowerCase()
                        ? 'ring-2 ring-offset-2 ring-slate-900'
                        : ''
                    }`}
                    style={{ backgroundColor: c.value }}
                    aria-label={c.name}
                  />
                ))}
              </div>
              <input
                type="color"
                value={defaultStyle.color}
                onChange={(e) => onChangeDefaultStyle({ color: e.target.value })}
                aria-label="Custom pointer color"
                className="w-7 h-7 rounded border border-slate-200 cursor-pointer p-0.5 bg-white"
              />
            </div>

            <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={defaultStyle.transparentFill}
                onChange={(e) =>
                  onChangeDefaultStyle({ transparentFill: e.target.checked })
                }
                className="rounded accent-blue-700"
              />
              <span>Transparent interior</span>
            </label>
          </div>

          <div className="space-y-3.5 pt-1 border-t border-slate-100">
            <label className="block">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Pointer Size</span>
                <span className="font-mono tabular-nums text-slate-500">
                  {defaultStyle.radius}px
                </span>
              </div>
              <input
                type="range"
                min={10}
                max={72}
                step={1}
                value={defaultStyle.radius}
                onChange={(e) =>
                  onChangeDefaultStyle({ radius: Number(e.target.value) })
                }
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <label className="block">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Line Weight</span>
                <span className="font-mono tabular-nums text-slate-500">
                  {defaultStyle.strokeWidth.toFixed(1)}px
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={8}
                step={0.5}
                value={defaultStyle.strokeWidth}
                onChange={(e) =>
                  onChangeDefaultStyle({ strokeWidth: Number(e.target.value) })
                }
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>

            <label className="block">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700">Number Scale</span>
                <span className="font-mono tabular-nums text-slate-500">
                  {Math.round(defaultStyle.fontScale * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0.65}
                max={1.35}
                step={0.05}
                value={defaultStyle.fontScale}
                onChange={(e) =>
                  onChangeDefaultStyle({ fontScale: Number(e.target.value) })
                }
                className="w-full accent-blue-700 cursor-pointer"
              />
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 space-y-2">
            <button
              type="button"
              disabled={balloons.length === 0}
              onClick={onApplyStyleToAll}
              className="w-full inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
            >
              <Paintbrush className="w-3.5 h-3.5" />
              <span>Apply Style to All Pointers</span>
            </button>

            <button
              type="button"
              disabled={balloons.length === 0}
              onClick={onRenumber}
              className="w-full inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
            >
              <ListOrdered className="w-3.5 h-3.5" />
              <span>Renumber Sequentially (1 - N)</span>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
