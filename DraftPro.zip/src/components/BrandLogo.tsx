export const BRAND_LOGO_PATHS = {
  outerHex: 'M8 2H36L42 8V36L36 42H8L2 36V8L8 2Z',
  innerHex: 'M8.5 3.5H35.5L40.5 8.5V35.5L35.5 40.5H8.5L3.5 35.5V8.5L8.5 3.5Z',
  cornerTicks: 'M8 12V8H12M32 8H36V12M36 32V36H32M12 36H8V32',
  teardrop: 'M11 22L21.5 14.3A9.5 9.5 0 1 1 21.5 29.7L11 22Z',
  dMonogram:
    'M24 18.2H26.4C28.45 18.2 29.8 19.75 29.8 22C29.8 24.25 28.45 25.8 26.4 25.8H24V18.2ZM25.65 19.65V24.35H26.35C27.5 24.35 28.15 23.5 28.15 22C28.15 20.5 27.5 19.65 26.35 19.65H25.65Z',
} as const;

export function BrandLogoVectorContent() {
  return (
    <>
      <path d={BRAND_LOGO_PATHS.outerHex} fill="#0F172A" />
      <path d={BRAND_LOGO_PATHS.innerHex} stroke="#334155" strokeWidth="1.2" fill="none" />
      <path
        d={BRAND_LOGO_PATHS.cornerTicks}
        stroke="#60A5FA"
        strokeWidth="1.4"
        strokeLinecap="square"
        fill="none"
        opacity="0.7"
      />
      <path d={BRAND_LOGO_PATHS.teardrop} fill="#2563EB" />
      <circle cx="26.2" cy="22" r="6.3" fill="#FFFFFF" />
      <path d={BRAND_LOGO_PATHS.dMonogram} fill="#0F172A" />
    </>
  );
}

interface BrandLogoProps {
  className?: string;
}

export function BrandLogo({ className = 'w-9 h-9' }: BrandLogoProps) {
  return (
    <svg
      viewBox="0 0 44 44"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <BrandLogoVectorContent />
    </svg>
  );
}
