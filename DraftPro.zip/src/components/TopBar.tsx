import { useState, useRef, useEffect } from 'react';
import {
  Home,
  Upload,
  Download,
  FileText,
  Image as ImageIcon,
  FileSpreadsheet,
  Save,
  FolderOpen,
  ChevronDown,
} from 'lucide-react';
import type { LoadedDocument } from '../types/drawing';
import { BrandLogo } from './BrandLogo';

interface TopBarProps {
  document: LoadedDocument | null;
  currentPage: number;
  balloonCount: number;
  exporting: string | null;
  showHomeAction: boolean;
  onGoHome: () => void;
  onTriggerUpload: () => void;
  onTriggerLoadProject: () => void;
  onExportPDF: () => void;
  onExportPNG: () => void;
  onExportXLSX: () => void;
  onExportReportPDF: () => void;
  onSaveProject: () => void;
}

export function TopBar({
  document: doc,
  currentPage,
  balloonCount,
  exporting,
  showHomeAction,
  onGoHome,
  onTriggerUpload,
  onTriggerLoadProject,
  onExportPDF,
  onExportPNG,
  onExportXLSX,
  onExportReportPDF,
  onSaveProject,
}: TopBarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', handleOutside);
    return () => window.removeEventListener('mousedown', handleOutside);
  }, [menuOpen]);

  const brandLockup = (
    <span className="inline-flex items-center gap-2.5 text-left whitespace-nowrap shrink-0">
      <BrandLogo className="w-8 h-8 shrink-0" />
      <span className="flex flex-col leading-none">
        <span
          className="text-[13px] font-bold tracking-tight text-slate-900"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          DRAFT PRO MANUFACTURING SUITE
        </span>
        <span className="text-[9.5px] font-semibold tracking-[0.14em] text-blue-700 mt-1">
          BY GAUTAM PRASAD
        </span>
      </span>
    </span>
  );

  return (
    <header className="h-14 bg-white border-b border-slate-200 px-5 flex items-center justify-between gap-6 shrink-0 z-30">
      {/* Zone 1: Brand mark & wordmark */}
      {showHomeAction ? (
        <button
          type="button"
          onClick={onGoHome}
          title="Back to Home Screen"
          className="group cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600 rounded-md shrink-0 hover:opacity-90 transition-opacity"
        >
          {brandLockup}
        </button>
      ) : (
        brandLockup
      )}

      {/* Zone 2: Active document metadata (clean unboxed text with separators) */}
      <div className="min-w-0 flex-1 flex items-center justify-center">
        {doc ? (
          <div className="flex items-center gap-2.5 text-sm text-slate-600 min-w-0">
            <span className="font-medium text-slate-900 truncate max-w-md" title={doc.fileName}>
              {doc.fileName}
            </span>
            <span aria-hidden="true" className="text-slate-300 shrink-0">
              ·
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-500 whitespace-nowrap shrink-0">
              {doc.fileType.toUpperCase()}
            </span>
            <span aria-hidden="true" className="text-slate-300 shrink-0">
              ·
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-500 whitespace-nowrap shrink-0">
              Page {currentPage + 1}/{doc.pages.length}
            </span>
            <span aria-hidden="true" className="text-slate-300 shrink-0">
              ·
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-600 whitespace-nowrap shrink-0">
              {balloonCount} {balloonCount === 1 ? 'balloon' : 'balloons'}
            </span>
          </div>
        ) : (
          <span className="text-sm text-slate-500 truncate">
            PDF, TIFF, and image engineering drawing workbench
          </span>
        )}
      </div>

      {/* Zone 3: Home, Upload & Export primary actions */}
      <div className="flex items-center gap-2.5 shrink-0">
        {showHomeAction && (
          <button
            type="button"
            onClick={onGoHome}
            title="Back to Home Screen"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:border-slate-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Home</span>
          </button>
        )}

        <button
          type="button"
          onClick={onTriggerUpload}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 hover:border-slate-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Upload Drawing</span>
        </button>

        <div className="relative" ref={menuRef}>
          <button
            type="button"
            disabled={!doc || Boolean(exporting)}
            onClick={() => setMenuOpen((prev) => !prev)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 disabled:opacity-45 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{exporting ? `Exporting ${exporting}...` : 'Export'}</span>
            <ChevronDown className="w-3.5 h-3.5 opacity-80" />
          </button>

          {menuOpen && doc && (
            <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-lg shadow-lg py-1.5 z-50">
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportPDF();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-blue-700 shrink-0" />
                <div>
                  <div className="font-medium text-slate-900">Ballooned Drawing (PDF)</div>
                  <div className="text-[11px] text-slate-500">All pages with vector balloons</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportPNG();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <ImageIcon className="w-4 h-4 text-blue-700 shrink-0" />
                <div>
                  <div className="font-medium text-slate-900">High-Res Drawing (PNG)</div>
                  <div className="text-[11px] text-slate-500">Current page at full resolution</div>
                </div>
              </button>

              <div className="my-1.5 border-t border-slate-100" />

              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportXLSX();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-700 shrink-0" />
                <div>
                  <div className="font-medium text-slate-900">Inspection Sheet (.xlsx)</div>
                  <div className="text-[11px] text-slate-500">Formatted Sample Inspection Report</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onExportReportPDF();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-emerald-700 shrink-0" />
                <div>
                  <div className="font-medium text-slate-900">Inspection Report (PDF)</div>
                  <div className="text-[11px] text-slate-500">Printable A4 report sheet</div>
                </div>
              </button>

              <div className="my-1.5 border-t border-slate-100" />

              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onSaveProject();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <Save className="w-4 h-4 text-slate-500 shrink-0" />
                <span>Save Project (.json)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onTriggerLoadProject();
                }}
                className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer"
              >
                <FolderOpen className="w-4 h-4 text-slate-500 shrink-0" />
                <span>Load Project (.json)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
