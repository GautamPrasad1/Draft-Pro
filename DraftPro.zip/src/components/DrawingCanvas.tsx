import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Upload,
  ZoomIn,
  ZoomOut,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Loader2,
} from 'lucide-react';
import type {
  AnnotationPatch,
  BalloonItem,
  BalloonStyle,
  BoxAnnotation,
  DrawingAnnotation,
  DrawingPage,
  LoadedDocument,
  StampAnnotation,
  ToolMode,
} from '../types/drawing';
import {
  circleSvgSubpath,
  computeFontSize,
  DRAWING_BRAND_STAMP_TEXT,
  getDrawingBrandStampMetrics,
  getLeaderArrowGeometry,
  getShapePolygonPoints,
  getTangentTeardropGeometry,
  getWedgePoints,
  pointsToSvgString,
} from '../utils/balloonGeometry';
import { BrandLogo, BrandLogoVectorContent } from './BrandLogo';

export interface BalloonMoveUpdate {
  id: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
}

interface DrawingCanvasProps {
  document: LoadedDocument | null;
  currentPage: number;
  loadingMessage: string | null;
  errorMessage: string | null;
  activeTool: ToolMode;
  nextNumber: number;
  defaultStyle: BalloonStyle;
  balloons: BalloonItem[];
  annotations: DrawingAnnotation[];
  selectedBalloonIds: string[];
  selectedAnnotationId: string | null;
  fitSignal: number;
  focusTarget: { x: number; y: number; ts: number } | null;
  onSelectPage: (index: number) => void;
  onSelectBalloon: (id: string, toggle?: boolean) => void;
  onSelectAnnotation: (id: string | null) => void;
  onClearSelection: () => void;
  onAddBalloon: (x: number, y: number, targetX: number, targetY: number) => void;
  onMoveBalloonsLive: (updates: BalloonMoveUpdate[], skipCapture?: boolean) => void;
  onDuplicateBalloonsForDrag: (
    sourceIds: string[],
    restoreOriginals?: BalloonMoveUpdate[]
  ) => string[];
  onCommitHistory: () => void;
  onQuickEditBalloonLabel: (id: string, label: string) => void;
  onAddStamp: (x: number, y: number) => void;
  onAddBox: (x: number, y: number, width: number, height: number) => void;
  onMoveAnnotationLive: (id: string, patch: AnnotationPatch) => void;
  onUploadFile: (file: File) => void;
  onTriggerFilePicker: () => void;
}

interface DraftBalloon {
  targetX: number;
  targetY: number;
  x: number;
  y: number;
  moved: boolean;
}

interface DraftBox {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
}

interface DragBalloonOrigin {
  id: string;
  origX: number;
  origY: number;
  origTargetX: number;
  origTargetY: number;
}

type DragState =
  | { type: 'pan'; startClientX: number; startClientY: number; startPanX: number; startPanY: number }
  | {
      type: 'balloon-body';
      clickedId: string;
      ctrlOnDown: boolean;
      items: DragBalloonOrigin[];
      startImgX: number;
      startImgY: number;
      moved: boolean;
      duplicated: boolean;
    }
  | {
      type: 'balloon-tip';
      id: string;
      origX: number;
      origY: number;
      moved: boolean;
    }
  | {
      type: 'annotation-move';
      id: string;
      startImgX: number;
      startImgY: number;
      origX: number;
      origY: number;
      moved: boolean;
    }
  | {
      type: 'box-resize';
      id: string;
      startImgX: number;
      startImgY: number;
      origWidth: number;
      origHeight: number;
      moved: boolean;
    };

export function DrawingCanvas({
  document: doc,
  currentPage,
  loadingMessage,
  errorMessage,
  activeTool,
  nextNumber,
  defaultStyle,
  balloons,
  annotations,
  selectedBalloonIds,
  selectedAnnotationId,
  fitSignal,
  focusTarget,
  onSelectPage,
  onSelectBalloon,
  onSelectAnnotation,
  onClearSelection,
  onAddBalloon,
  onMoveBalloonsLive,
  onDuplicateBalloonsForDrag,
  onCommitHistory,
  onQuickEditBalloonLabel,
  onAddStamp,
  onAddBox,
  onMoveAnnotationLive,
  onUploadFile,
  onTriggerFilePicker,
}: DrawingCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const viewRef = useRef({ zoom: 1, pan: { x: 0, y: 0 } });
  const [spacePressed, setSpacePressed] = useState(false);
  const [isDragOverFile, setIsDragOverFile] = useState(false);

  const [draftBalloon, setDraftBalloon] = useState<DraftBalloon | null>(null);
  const [draftBox, setDraftBox] = useState<DraftBox | null>(null);
  const [inlineEdit, setInlineEdit] = useState<{ id: string; value: string } | null>(null);

  const dragRef = useRef<DragState | null>(null);
  const page: DrawingPage | null = doc ? doc.pages[currentPage] ?? null : null;

  const updateView = useCallback((nextZoom: number, nextPan: { x: number; y: number }) => {
    viewRef.current = { zoom: nextZoom, pan: nextPan };
    setZoom(nextZoom);
    setPan(nextPan);
  }, []);

  const pageBalloons = balloons.filter((b) => b.pageIndex === currentPage);
  const pageAnnotations = annotations.filter((a) => a.pageIndex === currentPage);

  // Effective sheet dimensions after rotation
  const sheetDims = page
    ? page.rotation === 90 || page.rotation === 270
      ? { w: page.height, h: page.width }
      : { w: page.width, h: page.height }
    : { w: 1, h: 1 };

  const fitToViewport = useCallback(() => {
    if (!containerRef.current || !page) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pad = 48;
    const availW = Math.max(200, rect.width - pad * 2);
    const availH = Math.max(200, rect.height - pad * 2);
    const rotated = page.rotation === 90 || page.rotation === 270;
    const w = rotated ? page.height : page.width;
    const h = rotated ? page.width : page.height;
    const nextZoom = Math.min(availW / w, availH / h, 2.5);
    const nextPanX = (rect.width - w * nextZoom) / 2;
    const nextPanY = (rect.height - h * nextZoom) / 2;
    updateView(nextZoom, { x: nextPanX, y: nextPanY });
  }, [page, updateView]);

  // Auto-fit when page changes, rotation changes, or fit signal triggers
  useEffect(() => {
    fitToViewport();
  }, [fitToViewport, fitSignal, doc?.fileName, currentPage, page?.rotation]);

  // Pan to focused balloon when selected from right table
  useEffect(() => {
    if (!focusTarget || !containerRef.current || !page) return;
    const rect = containerRef.current.getBoundingClientRect();
    let rx = focusTarget.x;
    let ry = focusTarget.y;
    if (page.rotation === 90) {
      rx = page.height - focusTarget.y;
      ry = focusTarget.x;
    } else if (page.rotation === 180) {
      rx = page.width - focusTarget.x;
      ry = page.height - focusTarget.y;
    } else if (page.rotation === 270) {
      rx = focusTarget.y;
      ry = page.width - focusTarget.x;
    }
    const targetZoom = Math.max(viewRef.current.zoom, 0.85);
    updateView(targetZoom, {
      x: rect.width / 2 - rx * targetZoom,
      y: rect.height / 2 - ry * targetZoom,
    });
  }, [focusTarget]); // eslint-disable-line react-hooks/exhaustive-deps

  // Track Spacebar for quick canvas panning
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.code === 'Space' &&
        !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)
      ) {
        e.preventDefault();
        setSpacePressed(true);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') setSpacePressed(false);
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  // Convert viewport client coordinates -> native (unrotated) image coordinates
  const clientToImage = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } => {
      if (!containerRef.current || !page) return { x: 0, y: 0 };
      const rect = containerRef.current.getBoundingClientRect();
      const sheetX = (clientX - rect.left - pan.x) / zoom;
      const sheetY = (clientY - rect.top - pan.y) / zoom;

      if (page.rotation === 90) {
        return { x: sheetY, y: page.height - sheetX };
      }
      if (page.rotation === 180) {
        return { x: page.width - sheetX, y: page.height - sheetY };
      }
      if (page.rotation === 270) {
        return { x: page.width - sheetY, y: sheetX };
      }
      return { x: sheetX, y: sheetY };
    },
    [page, pan, zoom]
  );

  // Native non-passive wheel listener for smooth, cursor-anchored mouse scroll zoom in/out
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !page) return;

    const onNativeWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const rect = el.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      // Normalize deltaY across pixel, line (Windows mouse wheel), and page modes
      let delta = e.deltaY;
      if (e.deltaMode === 1) delta *= 24;
      else if (e.deltaMode === 2) delta *= 240;

      // Clamp extreme single-event spikes and apply smooth exponential zoom
      const clampedDelta = Math.max(-240, Math.min(240, delta));
      const sensitivity = e.ctrlKey ? 0.008 : 0.0018;
      const factor = Math.exp(-clampedDelta * sensitivity);

      const { zoom: curZoom, pan: curPan } = viewRef.current;
      const nextZoom = Math.max(0.1, Math.min(12, curZoom * factor));
      const scaleRatio = nextZoom / curZoom;

      updateView(nextZoom, {
        x: mouseX - (mouseX - curPan.x) * scaleRatio,
        y: mouseY - (mouseY - curPan.y) * scaleRatio,
      });
    };

    el.addEventListener('wheel', onNativeWheel, { passive: false });
    return () => el.removeEventListener('wheel', onNativeWheel);
  }, [page, updateView]);

  const adjustZoomCenter = useCallback(
    (multiplier: number) => {
      if (!containerRef.current || !page) return;
      const rect = containerRef.current.getBoundingClientRect();
      const cx = rect.width / 2;
      const cy = rect.height / 2;
      const { zoom: curZoom, pan: curPan } = viewRef.current;
      const nextZoom = Math.max(0.1, Math.min(12, curZoom * multiplier));
      const ratio = nextZoom / curZoom;
      updateView(nextZoom, {
        x: cx - (cx - curPan.x) * ratio,
        y: cy - (cy - curPan.y) * ratio,
      });
    },
    [page, updateView]
  );

  // Keyboard +/- zoom shortcuts
  useEffect(() => {
    if (!page) return;
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      ) {
        return;
      }
      if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        adjustZoomCenter(1.2);
      } else if (e.key === '-') {
        e.preventDefault();
        adjustZoomCenter(1 / 1.2);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [page, adjustZoomCenter]);

  const handleViewportPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!page) return;
    if (inlineEdit) {
      onQuickEditBalloonLabel(inlineEdit.id, inlineEdit.value);
      setInlineEdit(null);
    }

    // Middle click, Pan tool, or Spacebar drag
    if (e.button === 1 || activeTool === 'pan' || spacePressed) {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      dragRef.current = {
        type: 'pan',
        startClientX: e.clientX,
        startClientY: e.clientY,
        startPanX: pan.x,
        startPanY: pan.y,
      };
      return;
    }

    if (e.button !== 0) return;

    const pt = clientToImage(e.clientX, e.clientY);

    if (activeTool === 'balloon') {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      setDraftBalloon({
        targetX: pt.x,
        targetY: pt.y,
        x: pt.x,
        y: pt.y,
        moved: false,
      });
      return;
    }

    if (activeTool === 'stamp') {
      e.preventDefault();
      onAddStamp(pt.x, pt.y);
      return;
    }

    if (activeTool === 'box') {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      setDraftBox({
        startX: pt.x,
        startY: pt.y,
        endX: pt.x,
        endY: pt.y,
      });
      return;
    }

    if (activeTool === 'select') {
      onClearSelection();
    }
  };

  const handleViewportPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!page) return;

    if (draftBalloon) {
      const pt = clientToImage(e.clientX, e.clientY);
      const dist = Math.hypot(pt.x - draftBalloon.targetX, pt.y - draftBalloon.targetY);
      setDraftBalloon((prev) =>
        prev
          ? {
              ...prev,
              x: pt.x,
              y: pt.y,
              moved: prev.moved || dist > 10,
            }
          : null
      );
      return;
    }

    if (draftBox) {
      const pt = clientToImage(e.clientX, e.clientY);
      setDraftBox((prev) => (prev ? { ...prev, endX: pt.x, endY: pt.y } : null));
      return;
    }

    const drag = dragRef.current;
    if (!drag) return;

    if (drag.type === 'pan') {
      updateView(viewRef.current.zoom, {
        x: drag.startPanX + (e.clientX - drag.startClientX),
        y: drag.startPanY + (e.clientY - drag.startClientY),
      });
      return;
    }

    const pt = clientToImage(e.clientX, e.clientY);

    if (drag.type === 'balloon-body') {
      const dx = pt.x - drag.startImgX;
      const dy = pt.y - drag.startImgY;
      const dist = Math.hypot(dx, dy);

      // Ignore tiny micro-jitter before committing move or Ctrl+Drag copy
      if (!drag.moved && dist < 4) return;

      // Ctrl/Cmd + Drag duplicates the dragged balloon(s) while preserving originals
      if ((drag.ctrlOnDown || e.ctrlKey || e.metaKey) && !drag.duplicated) {
        const clonedIds = onDuplicateBalloonsForDrag(
          drag.items.map((item) => item.id),
          drag.moved
            ? drag.items.map((item) => ({
                id: item.id,
                x: item.origX,
                y: item.origY,
                targetX: item.origTargetX,
                targetY: item.origTargetY,
              }))
            : undefined
        );
        if (clonedIds.length === drag.items.length) {
          drag.items = drag.items.map((item, idx) => ({
            ...item,
            id: clonedIds[idx],
          }));
          drag.duplicated = true;
        }
      }

      drag.moved = true;
      const pinTip = e.altKey;
      onMoveBalloonsLive(
        drag.items.map((item) => ({
          id: item.id,
          x: item.origX + dx,
          y: item.origY + dy,
          targetX: pinTip ? item.origTargetX : item.origTargetX + dx,
          targetY: pinTip ? item.origTargetY : item.origTargetY + dy,
        })),
        drag.duplicated
      );
      return;
    }

    if (drag.type === 'balloon-tip') {
      drag.moved = true;
      onMoveBalloonsLive([{ id: drag.id, x: drag.origX, y: drag.origY, targetX: pt.x, targetY: pt.y }]);
      return;
    }

    if (drag.type === 'annotation-move') {
      drag.moved = true;
      onMoveAnnotationLive(drag.id, {
        x: drag.origX + (pt.x - drag.startImgX),
        y: drag.origY + (pt.y - drag.startImgY),
      });
      return;
    }

    if (drag.type === 'box-resize') {
      drag.moved = true;
      onMoveAnnotationLive(drag.id, {
        width: Math.max(24, drag.origWidth + (pt.x - drag.startImgX)),
        height: Math.max(24, drag.origHeight + (pt.y - drag.startImgY)),
      });
    }
  };

  const handleViewportPointerUp = () => {
    if (draftBalloon) {
      const { x, y, targetX, targetY, moved } = draftBalloon;
      if (moved && defaultStyle.pointerStyle !== 'none') {
        onAddBalloon(x, y, targetX, targetY);
      } else if (defaultStyle.pointerStyle === 'wedge') {
        // Quick click placement: classic tangent teardrop pointing left
        const offset = defaultStyle.radius * 2.15;
        onAddBalloon(x, y, x - offset, y);
      } else if (defaultStyle.pointerStyle === 'arrow') {
        const offset = defaultStyle.radius * 2.4;
        onAddBalloon(x, y, x - offset * 0.72, y + offset * 0.72);
      } else {
        onAddBalloon(x, y, x, y);
      }
      setDraftBalloon(null);
      return;
    }

    if (draftBox) {
      const x = Math.min(draftBox.startX, draftBox.endX);
      const y = Math.min(draftBox.startY, draftBox.endY);
      const w = Math.abs(draftBox.endX - draftBox.startX);
      const h = Math.abs(draftBox.endY - draftBox.startY);
      if (w > 12 && h > 12) {
        onAddBox(x, y, w, h);
      }
      setDraftBox(null);
      return;
    }

    if (dragRef.current) {
      const drag = dragRef.current;
      dragRef.current = null;
      if (drag.type === 'balloon-body' && !drag.moved) {
        if (drag.ctrlOnDown) {
          // Pure Ctrl+Click toggles multi-selection without duplicating
          onSelectBalloon(drag.clickedId, true);
        } else if (selectedBalloonIds.length > 1 && selectedBalloonIds.includes(drag.clickedId)) {
          // Clicking one item of a multi-selection without dragging focuses just that item
          onSelectBalloon(drag.clickedId, false);
        }
        return;
      }
      if (drag.type !== 'pan' && drag.moved && !(drag.type === 'balloon-body' && drag.duplicated)) {
        onCommitHistory();
      }
    }
  };

  // Drag & Drop file onto canvas
  const handleDropFile = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOverFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onUploadFile(file);
    }
  };

  const rotationTransform = (() => {
    if (!page || page.rotation === 0) return undefined;
    if (page.rotation === 90) return `translate(${page.height}, 0) rotate(90)`;
    if (page.rotation === 180) return `translate(${page.width}, ${page.height}) rotate(180)`;
    return `translate(0, ${page.width}) rotate(-90)`;
  })();

  const cursorClass = spacePressed || activeTool === 'pan'
    ? 'cursor-grab active:cursor-grabbing'
    : activeTool === 'balloon' || activeTool === 'box' || activeTool === 'stamp'
    ? 'cursor-crosshair'
    : 'cursor-default';

  const selectedBalloonSet = new Set(selectedBalloonIds);

  const renderBalloonSVG = (b: BalloonItem, isPreview = false) => {
    const { x, y, targetX, targetY, style, label, subLabel } = b;
    const r = style.radius;
    const isSelected = !isPreview && selectedBalloonSet.has(b.id);
    const isCircleLike = style.shape === 'circle' || style.shape === 'split';
    const outerR = r + style.strokeWidth / 2;
    const innerR = Math.max(2, r - style.strokeWidth / 2);

    const teardrop =
      isCircleLike && style.pointerStyle === 'wedge'
        ? getTangentTeardropGeometry(x, y, targetX, targetY, outerR)
        : null;

    const wedgePts =
      !teardrop && style.pointerStyle === 'wedge'
        ? getWedgePoints(x, y, targetX, targetY, r)
        : null;
    const arrowGeom =
      style.pointerStyle === 'arrow'
        ? getLeaderArrowGeometry(x, y, targetX, targetY, r, style.strokeWidth)
        : null;

    const fontSize = computeFontSize(label, r, style.fontScale);
    const fill = style.transparentFill ? 'none' : style.fillColor;

    return (
      <g
        key={b.id}
        opacity={isPreview ? 0.78 : 1}
        className={isPreview ? 'pointer-events-none' : 'cursor-move'}
        onPointerDown={(e) => {
          if (isPreview || activeTool === 'pan' || spacePressed) return;
          if (activeTool === 'box' || activeTool === 'stamp') return;
          if (e.button !== 0) return;
          e.stopPropagation();

          const pt = clientToImage(e.clientX, e.clientY);
          const ctrlOnDown = e.ctrlKey || e.metaKey;
          const alreadySelected = selectedBalloonSet.has(b.id);

          if (!ctrlOnDown && !alreadySelected) {
            onSelectBalloon(b.id, false);
          }

          // Determine which balloons move together on drag
          const itemsToDrag: DragBalloonOrigin[] =
            alreadySelected && selectedBalloonIds.length > 1
              ? pageBalloons
                  .filter((pb) => selectedBalloonSet.has(pb.id))
                  .map((pb) => ({
                    id: pb.id,
                    origX: pb.x,
                    origY: pb.y,
                    origTargetX: pb.targetX,
                    origTargetY: pb.targetY,
                  }))
              : [
                  {
                    id: b.id,
                    origX: b.x,
                    origY: b.y,
                    origTargetX: b.targetX,
                    origTargetY: b.targetY,
                  },
                ];

          containerRef.current?.setPointerCapture(e.pointerId);
          dragRef.current = {
            type: 'balloon-body',
            clickedId: b.id,
            ctrlOnDown,
            items: itemsToDrag,
            startImgX: pt.x,
            startImgY: pt.y,
            moved: false,
            duplicated: false,
          };
        }}
        onDoubleClick={(e) => {
          if (isPreview) return;
          e.stopPropagation();
          onSelectBalloon(b.id, false);
          setInlineEdit({ id: b.id, value: b.label });
        }}
      >
        {/* Selection highlight ring */}
        {isSelected && (
          <circle
            cx={x}
            cy={y}
            r={outerR + Math.max(4, style.strokeWidth * 1.5)}
            fill="none"
            stroke="#2563EB"
            strokeWidth={Math.max(1.5, 2 / zoom)}
            strokeDasharray={`${Math.max(4, 5 / zoom)} ${Math.max(3, 3.5 / zoom)}`}
          />
        )}

        {teardrop ? (
          <>
            {style.transparentFill ? (
              <path
                d={`${teardrop.outerSvgPath} ${circleSvgSubpath(x, y, innerR)}`}
                fill={style.color}
                fillRule="evenodd"
              />
            ) : (
              <>
                <path d={teardrop.outerSvgPath} fill={style.color} />
                <circle cx={x} cy={y} r={innerR} fill={style.fillColor} />
              </>
            )}
            {style.shape === 'split' && (
              <line
                x1={x - innerR}
                y1={y}
                x2={x + innerR}
                y2={y}
                stroke={style.color}
                strokeWidth={style.strokeWidth}
              />
            )}
          </>
        ) : (
          <>
            {/* Pointer Wedge (non-circle shapes) */}
            {wedgePts && (
              <polygon points={pointsToSvgString(wedgePts)} fill={style.color} />
            )}

            {/* Leader Arrow */}
            {arrowGeom && (
              <g>
                <line
                  x1={arrowGeom.start.x}
                  y1={arrowGeom.start.y}
                  x2={arrowGeom.tip.x}
                  y2={arrowGeom.tip.y}
                  stroke={style.color}
                  strokeWidth={style.strokeWidth}
                  strokeLinecap="round"
                />
                <polygon points={pointsToSvgString(arrowGeom.head)} fill={style.color} />
              </g>
            )}

            {/* Balloon Shape */}
            {isCircleLike ? (
              <>
                <circle
                  cx={x}
                  cy={y}
                  r={r}
                  fill={fill}
                  stroke={style.color}
                  strokeWidth={style.strokeWidth}
                />
                {style.shape === 'split' && (
                  <line
                    x1={x - r}
                    y1={y}
                    x2={x + r}
                    y2={y}
                    stroke={style.color}
                    strokeWidth={style.strokeWidth}
                  />
                )}
              </>
            ) : (
              <polygon
                points={pointsToSvgString(getShapePolygonPoints(style.shape, x, y, r))}
                fill={fill}
                stroke={style.color}
                strokeWidth={style.strokeWidth}
                strokeLinejoin="miter"
              />
            )}
          </>
        )}

        {/* Balloon Label */}
        {style.shape === 'split' ? (
          <>
            <text
              x={x}
              y={y - r * 0.34}
              textAnchor="middle"
              dominantBaseline="central"
              fill={style.color}
              fontFamily="JetBrains Mono, monospace"
              fontWeight={700}
              fontSize={Math.max(8, r * 0.62 * style.fontScale)}
              style={{ userSelect: 'none' }}
            >
              {label}
            </text>
            <text
              x={x}
              y={y + r * 0.4}
              textAnchor="middle"
              dominantBaseline="central"
              fill={style.color}
              fontFamily="JetBrains Mono, monospace"
              fontWeight={600}
              fontSize={Math.max(7, r * 0.48 * style.fontScale)}
              style={{ userSelect: 'none' }}
            >
              {subLabel || '-'}
            </text>
          </>
        ) : (
          <text
            x={x}
            y={y + fontSize * 0.04}
            textAnchor="middle"
            dominantBaseline="central"
            fill={style.color}
            fontFamily="JetBrains Mono, monospace"
            fontWeight={700}
            fontSize={fontSize}
            style={{ userSelect: 'none' }}
          >
            {label}
          </text>
        )}

        {/* Invisible tip hit-zone to re-aim/rotate pointer without any visible dot or circle */}
        {isSelected && style.pointerStyle !== 'none' && (
          <circle
            cx={targetX}
            cy={targetY}
            r={Math.max(8, 10 / zoom)}
            fill="transparent"
            stroke="none"
            className="cursor-crosshair"
            onPointerDown={(e) => {
              if (e.button !== 0 || e.ctrlKey || e.metaKey) return;
              e.stopPropagation();
              containerRef.current?.setPointerCapture(e.pointerId);
              dragRef.current = {
                type: 'balloon-tip',
                id: b.id,
                origX: b.x,
                origY: b.y,
                moved: false,
              };
            }}
          />
        )}
      </g>
    );
  };

  return (
    <div
      ref={containerRef}
      onPointerDown={handleViewportPointerDown}
      onPointerMove={handleViewportPointerMove}
      onPointerUp={handleViewportPointerUp}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragOverFile(true);
      }}
      onDragLeave={() => setIsDragOverFile(false)}
      onDrop={handleDropFile}
      className={`flex-1 relative overflow-hidden drafting-grid select-none ${cursorClass}`}
    >
      {/* Loading overlay */}
      {loadingMessage && (
        <div className="absolute inset-0 bg-white/80 backdrop-blur-[2px] z-40 flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-7 h-7 text-blue-700 animate-spin" />
          <p className="text-sm font-medium text-slate-800">{loadingMessage}</p>
        </div>
      )}

      {/* Drag-file highlight overlay */}
      {isDragOverFile && (
        <div className="absolute inset-4 z-40 rounded-xl border-2 border-dashed border-blue-600 bg-blue-50/80 flex flex-col items-center justify-center gap-2 pointer-events-none">
          <Upload className="w-8 h-8 text-blue-700" />
          <p className="text-sm font-semibold text-blue-900">
            Drop your PDF, TIFF, or image drawing to load
          </p>
        </div>
      )}

      {/* Empty State / Upload Dropzone */}
      {!page && !loadingMessage && (
        <div className="absolute inset-0 flex items-center justify-center p-8">
          <div className="w-full max-w-xl bg-white border border-slate-200 rounded-xl p-10 text-center">
            <BrandLogo className="w-14 h-14 mx-auto mb-4" />
            <h1
              className="text-xl font-bold text-slate-900 tracking-tight"
              style={{ fontFamily: 'var(--font-display)', textWrap: 'balance' }}
            >
              DRAFT PRO MANUFACTURING SUITE
            </h1>
            <p className="text-[11px] font-semibold tracking-[0.18em] text-blue-700 mt-1 mb-4">
              BY GAUTAM PRASAD
            </p>
            <p className="text-sm text-slate-600 max-w-md mx-auto mb-6 leading-relaxed">
              Upload or drop a CAD engineering drawing to start ballooning and inspection reporting.
              Supports multi-page PDF, multi-frame TIFF, PNG, JPG, and WebP at full resolution.
            </p>

            {errorMessage && (
              <div className="mb-5 px-4 py-2.5 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                {errorMessage}
              </div>
            )}

            <div className="flex items-center justify-center mb-7">
              <button
                type="button"
                onClick={onTriggerFilePicker}
                className="inline-flex items-center gap-2 px-6 py-2.5 text-sm font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Select Drawing File</span>
              </button>
            </div>

            <div className="pt-5 border-t border-slate-100 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-slate-500">
              <span>PDF (Multi-page)</span>
              <span aria-hidden="true">·</span>
              <span>TIFF / TIF</span>
              <span aria-hidden="true">·</span>
              <span>PNG / JPG / WebP</span>
              <span aria-hidden="true">·</span>
              <span>Export PDF, PNG &amp; Excel (.xlsx)</span>
            </div>
          </div>
        </div>
      )}

      {/* Rendered Drawing + Synchronized Vector SVG Overlay */}
      {page && (
        <div
          className="absolute top-0 left-0 origin-top-left"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            width: sheetDims.w,
            height: sheetDims.h,
          }}
        >
          <div className="w-full h-full bg-white shadow-[0_8px_32px_rgba(15,23,42,0.12)] ring-1 ring-slate-300/80 relative">
            <svg
              width={sheetDims.w}
              height={sheetDims.h}
              viewBox={`0 0 ${sheetDims.w} ${sheetDims.h}`}
              className="block overflow-visible"
            >
              <g transform={rotationTransform}>
                <image
                  href={page.dataUrl}
                  x={0}
                  y={0}
                  width={page.width}
                  height={page.height}
                  preserveAspectRatio="none"
                />

                {/* Area Callout Boxes */}
                {pageAnnotations
                  .filter((a): a is BoxAnnotation => a.kind === 'box')
                  .map((box) => {
                    const isSel = selectedAnnotationId === box.id;
                    const handleSize = Math.max(8, 10 / zoom);
                    return (
                      <g
                        key={box.id}
                        className="cursor-move"
                        onPointerDown={(e) => {
                          if (activeTool === 'pan' || spacePressed) return;
                          if (activeTool === 'balloon' || activeTool === 'stamp') return;
                          e.stopPropagation();
                          onSelectAnnotation(box.id);
                          const pt = clientToImage(e.clientX, e.clientY);
                          containerRef.current?.setPointerCapture(e.pointerId);
                          dragRef.current = {
                            type: 'annotation-move',
                            id: box.id,
                            startImgX: pt.x,
                            startImgY: pt.y,
                            origX: box.x,
                            origY: box.y,
                            moved: false,
                          };
                        }}
                      >
                        <rect
                          x={box.x}
                          y={box.y}
                          width={box.width}
                          height={box.height}
                          fill="transparent"
                          stroke={box.color}
                          strokeWidth={box.strokeWidth}
                          strokeDasharray={
                            box.dashed
                              ? `${box.strokeWidth * 3} ${box.strokeWidth * 2}`
                              : undefined
                          }
                        />
                        {box.label.trim() && (
                          <g>
                            <rect
                              x={box.x}
                              y={box.y - Math.max(20, box.strokeWidth * 7)}
                              width={Math.max(48, box.label.length * 8.5 + 14)}
                              height={Math.max(20, box.strokeWidth * 7)}
                              fill={box.color}
                            />
                            <text
                              x={box.x + 7}
                              y={box.y - Math.max(20, box.strokeWidth * 7) / 2}
                              fill="#FFFFFF"
                              fontSize={Math.max(12, box.strokeWidth * 4.5)}
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight={600}
                              dominantBaseline="central"
                              style={{ userSelect: 'none' }}
                            >
                              {box.label}
                            </text>
                          </g>
                        )}
                        {isSel && (
                          <>
                            <rect
                              x={box.x - 4}
                              y={box.y - 4}
                              width={box.width + 8}
                              height={box.height + 8}
                              fill="none"
                              stroke="#2563EB"
                              strokeWidth={Math.max(1.5, 2 / zoom)}
                              strokeDasharray="6 4"
                            />
                            {/* Bottom-right corner resize handle */}
                            <rect
                              x={box.x + box.width - handleSize / 2}
                              y={box.y + box.height - handleSize / 2}
                              width={handleSize}
                              height={handleSize}
                              fill="#FFFFFF"
                              stroke="#2563EB"
                              strokeWidth={Math.max(1.5, 2 / zoom)}
                              className="cursor-nwse-resize"
                              onPointerDown={(e) => {
                                e.stopPropagation();
                                const pt = clientToImage(e.clientX, e.clientY);
                                containerRef.current?.setPointerCapture(e.pointerId);
                                dragRef.current = {
                                  type: 'box-resize',
                                  id: box.id,
                                  startImgX: pt.x,
                                  startImgY: pt.y,
                                  origWidth: box.width,
                                  origHeight: box.height,
                                  moved: false,
                                };
                              }}
                            />
                          </>
                        )}
                      </g>
                    );
                  })}

                {/* Revision Stamps */}
                {pageAnnotations
                  .filter((a): a is StampAnnotation => a.kind === 'stamp')
                  .map((st) => {
                    const isSel = selectedAnnotationId === st.id;
                    const lines = st.text.split('\n');
                    const lineH = st.fontSize * 1.25;
                    const maxChars = Math.max(4, ...lines.map((l) => l.length));
                    const padX = st.fontSize * 0.55;
                    const padY = st.fontSize * 0.35;
                    const estW = maxChars * st.fontSize * 0.62 + padX * 2;
                    const estH = lines.length * lineH + padY * 2;

                    return (
                      <g
                        key={st.id}
                        className="cursor-move"
                        onPointerDown={(e) => {
                          if (activeTool !== 'select' || spacePressed) return;
                          e.stopPropagation();
                          onSelectAnnotation(st.id);
                          const pt = clientToImage(e.clientX, e.clientY);
                          containerRef.current?.setPointerCapture(e.pointerId);
                          dragRef.current = {
                            type: 'annotation-move',
                            id: st.id,
                            startImgX: pt.x,
                            startImgY: pt.y,
                            origX: st.x,
                            origY: st.y,
                            moved: false,
                          };
                        }}
                      >
                        {st.bordered && (
                          <rect
                            x={st.x}
                            y={st.y}
                            width={estW}
                            height={estH}
                            fill="rgba(255,255,255,0.92)"
                            stroke={st.color}
                            strokeWidth={Math.max(2, st.fontSize * 0.1)}
                          />
                        )}
                        {lines.map((line, i) => (
                          <text
                            key={i}
                            x={st.x + estW / 2}
                            y={st.y + padY + lineH * (i + 0.5)}
                            textAnchor="middle"
                            dominantBaseline="central"
                            fill={st.color}
                            fontFamily="Plus Jakarta Sans, sans-serif"
                            fontWeight={700}
                            fontSize={st.fontSize}
                            style={{ userSelect: 'none' }}
                          >
                            {line}
                          </text>
                        ))}
                        {isSel && (
                          <rect
                            x={st.x - 5}
                            y={st.y - 5}
                            width={estW + 10}
                            height={estH + 10}
                            fill="none"
                            stroke="#2563EB"
                            strokeWidth={Math.max(1.5, 2 / zoom)}
                            strokeDasharray="6 4"
                          />
                        )}
                      </g>
                    );
                  })}

                {/* Placed Balloons */}
                {pageBalloons.map((b) => renderBalloonSVG(b, false))}

                {/* Live Draft Balloon while clicking/dragging */}
                {draftBalloon &&
                  renderBalloonSVG(
                    {
                      id: '__draft__',
                      pageIndex: currentPage,
                      label: String(nextNumber),
                      subLabel: '',
                      x: draftBalloon.x,
                      y: draftBalloon.y,
                      targetX: draftBalloon.moved
                        ? draftBalloon.targetX
                        : defaultStyle.pointerStyle === 'wedge'
                        ? draftBalloon.x - defaultStyle.radius * 2.15
                        : draftBalloon.x,
                      targetY: draftBalloon.moved
                        ? draftBalloon.targetY
                        : draftBalloon.y,
                      style: defaultStyle,
                      description: '',
                      nominal: '',
                      tolerance: '',
                      inspectionMethod: '',
                      samples: ['', '', '', '', ''],
                      status: '',
                      type: 'Dimension',
                      zone: '',
                      criticality: 'Standard',
                      remarks: '',
                    },
                    true
                  )}

                {/* Live Draft Area Box */}
                {draftBox && (
                  <rect
                    x={Math.min(draftBox.startX, draftBox.endX)}
                    y={Math.min(draftBox.startY, draftBox.endY)}
                    width={Math.abs(draftBox.endX - draftBox.startX)}
                    height={Math.abs(draftBox.endY - draftBox.startY)}
                    fill="rgba(29, 78, 216, 0.06)"
                    stroke={defaultStyle.color}
                    strokeWidth={Math.max(2, defaultStyle.strokeWidth)}
                    strokeDasharray="8 5"
                  />
                )}
              </g>

              {/* Bottom-Left Outer Margin Stamp: Solid Logo + BY DRAFT PRO MANUFACTURING SUITE */}
              {(() => {
                const stamp = getDrawingBrandStampMetrics(sheetDims.w, sheetDims.h);
                const logoX = stamp.marginX;
                const logoY = Math.max(2, sheetDims.h - stamp.marginY - stamp.logoSize);
                const logoScale = stamp.logoSize / 44;
                return (
                  <g
                    className="pointer-events-none"
                    aria-label={DRAWING_BRAND_STAMP_TEXT}
                  >
                    <g transform={`translate(${logoX}, ${logoY}) scale(${logoScale})`}>
                      <BrandLogoVectorContent />
                    </g>
                    <text
                      x={logoX + stamp.logoSize + stamp.gap}
                      y={logoY + stamp.logoSize / 2 + stamp.fontSize * 0.03}
                      fill="#0F172A"
                      fontFamily="Plus Jakarta Sans, DM Sans, sans-serif"
                      fontWeight={700}
                      fontSize={stamp.fontSize}
                      letterSpacing="0.04em"
                      dominantBaseline="central"
                      style={{ userSelect: 'none' }}
                    >
                      {DRAWING_BRAND_STAMP_TEXT}
                    </text>
                  </g>
                );
              })()}
            </svg>
          </div>
        </div>
      )}

      {/* Quick Inline Balloon Label Editor Modal */}
      {inlineEdit && (
        <div
          className="absolute top-4 left-1/2 -translate-x-1/2 z-40 bg-white border border-slate-200 rounded-lg shadow-lg px-3 py-2 flex items-center gap-2"
          onPointerDown={(e) => e.stopPropagation()}
        >
          <span className="text-xs font-medium text-slate-600 whitespace-nowrap">
            Edit Balloon #
          </span>
          <input
            autoFocus
            type="text"
            value={inlineEdit.value}
            onChange={(e) =>
              setInlineEdit({ ...inlineEdit, value: e.target.value })
            }
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onQuickEditBalloonLabel(inlineEdit.id, inlineEdit.value);
                setInlineEdit(null);
              } else if (e.key === 'Escape') {
                setInlineEdit(null);
              }
            }}
            className="w-20 h-7 px-2 text-xs font-mono font-semibold text-slate-900 bg-slate-50 border border-blue-500 rounded focus:outline-none"
          />
          <button
            type="button"
            onClick={() => {
              onQuickEditBalloonLabel(inlineEdit.id, inlineEdit.value);
              setInlineEdit(null);
            }}
            className="px-2.5 py-1 text-xs font-medium text-white bg-blue-700 rounded hover:bg-blue-800 cursor-pointer"
          >
            Save
          </button>
        </div>
      )}

      {/* Bottom Floating Zoom & Multi-Page Controls */}
      {page && doc && (
        <div
          className="absolute bottom-4 left-4 z-30 flex items-center gap-2"
          onPointerDown={(e) => e.stopPropagation()}
        >
          <div className="bg-white border border-slate-200 rounded-lg shadow-xs flex items-center p-1 gap-0.5">
            <button
              type="button"
              onClick={() => adjustZoomCenter(1 / 1.2)}
              title="Zoom Out (-)"
              aria-label="Zoom Out"
              className="w-7 h-7 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={fitToViewport}
              title="Reset zoom to fit sheet"
              className="px-2 h-7 text-xs font-mono tabular-nums font-medium text-slate-700 hover:bg-slate-100 rounded cursor-pointer min-w-13 text-center"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button
              type="button"
              onClick={() => adjustZoomCenter(1.2)}
              title="Zoom In (+)"
              aria-label="Zoom In"
              className="w-7 h-7 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <div className="h-4 border-l border-slate-200 mx-0.5" />
            <button
              type="button"
              onClick={fitToViewport}
              title="Fit to Viewport (0)"
              aria-label="Fit to Viewport"
              className="w-7 h-7 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {doc.pages.length > 1 && (
            <div className="bg-white border border-slate-200 rounded-lg shadow-xs flex items-center p-1 gap-1">
              <button
                type="button"
                disabled={currentPage === 0}
                onClick={() => onSelectPage(currentPage - 1)}
                aria-label="Previous Page"
                className="w-7 h-7 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 text-xs font-mono tabular-nums text-slate-700 whitespace-nowrap">
                {currentPage + 1} / {doc.pages.length}
              </span>
              <button
                type="button"
                disabled={currentPage >= doc.pages.length - 1}
                onClick={() => onSelectPage(currentPage + 1)}
                aria-label="Next Page"
                className="w-7 h-7 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
