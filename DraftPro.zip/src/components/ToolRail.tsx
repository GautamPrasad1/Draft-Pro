import {
  MousePointer2,
  CircleDot,
  Hand,
  Type,
  SquareDashed,
  Undo2,
  Redo2,
  RotateCw,
  Maximize2,
} from 'lucide-react';
import type { ToolMode } from '../types/drawing';

interface ToolRailProps {
  activeTool: ToolMode;
  onSelectTool: (tool: ToolMode) => void;
  canUndo: boolean;
  canRedo: boolean;
  hasDocument: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onRotatePage: () => void;
  onFitView: () => void;
}

const TOOLS: { id: ToolMode; label: string; shortcut: string; icon: typeof MousePointer2 }[] = [
  { id: 'select', label: 'Select & Move', shortcut: 'V', icon: MousePointer2 },
  { id: 'balloon', label: 'Place Balloon', shortcut: 'B', icon: CircleDot },
  { id: 'pan', label: 'Pan Drawing', shortcut: 'H', icon: Hand },
  { id: 'stamp', label: 'Revision Stamp / Text', shortcut: 'T', icon: Type },
  { id: 'box', label: 'Area Callout Box', shortcut: 'R', icon: SquareDashed },
];

export function ToolRail({
  activeTool,
  onSelectTool,
  canUndo,
  canRedo,
  hasDocument,
  onUndo,
  onRedo,
  onRotatePage,
  onFitView,
}: ToolRailProps) {
  return (
    <aside
      aria-label="Drawing Tools"
      className="w-14 bg-white border-r border-slate-200 py-3 flex flex-col items-center justify-between shrink-0 z-20"
    >
      <div className="flex flex-col items-center gap-1.5">
        {TOOLS.map((tool) => {
          const Icon = tool.icon;
          const active = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              type="button"
              disabled={!hasDocument}
              onClick={() => onSelectTool(tool.id)}
              title={`${tool.label} (${tool.shortcut})`}
              aria-label={`${tool.label} (${tool.shortcut})`}
              aria-pressed={active}
              className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors relative cursor-pointer disabled:opacity-40 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-blue-600 ${
                active
                  ? 'bg-blue-700 text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="w-[18px] h-[18px]" />
            </button>
          );
        })}

        <div className="w-7 border-t border-slate-200 my-2" />

        <button
          type="button"
          disabled={!canUndo}
          onClick={onUndo}
          title="Undo (Ctrl+Z)"
          aria-label="Undo"
          className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <Undo2 className="w-[18px] h-[18px]" />
        </button>

        <button
          type="button"
          disabled={!canRedo}
          onClick={onRedo}
          title="Redo (Ctrl+Y)"
          aria-label="Redo"
          className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <Redo2 className="w-[18px] h-[18px]" />
        </button>
      </div>

      <div className="flex flex-col items-center gap-1.5">
        <button
          type="button"
          disabled={!hasDocument}
          onClick={onRotatePage}
          title="Rotate Sheet 90° Clockwise"
          aria-label="Rotate Sheet 90° Clockwise"
          className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <RotateCw className="w-[18px] h-[18px]" />
        </button>

        <button
          type="button"
          disabled={!hasDocument}
          onClick={onFitView}
          title="Fit Drawing to Viewport (0)"
          aria-label="Fit Drawing to Viewport"
          className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-600 hover:bg-slate-100 hover:text-slate-900 disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-blue-600"
        >
          <Maximize2 className="w-[18px] h-[18px]" />
        </button>
      </div>
    </aside>
  );
}
