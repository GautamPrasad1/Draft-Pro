import { ArrowLeft, FileSpreadsheet, FileText } from 'lucide-react';
import type { BalloonItem, InspectionReportMeta } from '../types/drawing';
import {
  formatBalloonSpecification,
  sortBalloonsForReport,
} from '../utils/inspectionSheetExport';

interface InspectionSheetViewProps {
  balloons: BalloonItem[];
  meta: InspectionReportMeta;
  hasDocument: boolean;
  onChangeMeta: (patch: Partial<InspectionReportMeta>) => void;
  onUpdateBalloon: (id: string, patch: Partial<BalloonItem>) => void;
  onBackToDrawing: () => void;
  onExportXLSX: () => void;
  onExportReportPDF: () => void;
}

const INSPECTION_METHODS = [
  'Vernier Caliper',
  'Digital Vernier',
  'Micrometer',
  'Height Gauge',
  'Pin Gauge',
  'Plug Gauge',
  'Thread Gauge',
  'Radius Gauge',
  'CMM',
  'Profile Projector',
  'Visual',
  'Scale',
];

export function InspectionSheetView({
  balloons,
  meta,
  hasDocument,
  onChangeMeta,
  onUpdateBalloon,
  onBackToDrawing,
  onExportXLSX,
  onExportReportPDF,
}: InspectionSheetViewProps) {
  const sorted = sortBalloonsForReport(balloons);
  const minRows = 25;
  const blankRowCount = Math.max(0, minRows - sorted.length);

  const handleSampleChange = (b: BalloonItem, sampleIdx: number, val: string) => {
    const next: [string, string, string, string, string] = [
      ...(b.samples ?? ['', '', '', '', '']),
    ] as [string, string, string, string, string];
    next[sampleIdx] = val;
    onUpdateBalloon(b.id, { samples: next });
  };

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-slate-100 overflow-hidden">
      {/* Inspection Sheet Action Bar */}
      <div className="h-12 bg-white border-b border-slate-200 px-4 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToDrawing}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{hasDocument ? 'Back to Drawing' : 'Back to Home'}</span>
          </button>
          <span className="text-xs text-slate-500">
            Click any cell to edit · Synced live with {sorted.length}{' '}
            {sorted.length === 1 ? 'balloon' : 'balloons'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onExportXLSX}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-emerald-700 rounded-md hover:bg-emerald-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Download Excel (.xlsx)</span>
          </button>
          <button
            type="button"
            onClick={onExportReportPDF}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 transition-colors cursor-pointer whitespace-nowrap"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Download Report PDF</span>
          </button>
        </div>
      </div>

      {/* Scrollable A4 Sheet Container */}
      <div className="flex-1 overflow-auto p-6">
        <datalist id="inspection-methods-list">
          {INSPECTION_METHODS.map((m) => (
            <option key={m} value={m} />
          ))}
        </datalist>

        <div className="max-w-[1060px] mx-auto bg-white shadow-sm border border-slate-900 text-slate-950">
          <table className="w-full border-collapse table-fixed text-xs">
            <colgroup>
              <col style={{ width: '5.5%' }} />
              <col style={{ width: '15.5%' }} />
              <col style={{ width: '16%' }} />
              <col style={{ width: '11.5%' }} />
              <col style={{ width: '6.3%' }} />
              <col style={{ width: '6.3%' }} />
              <col style={{ width: '6.3%' }} />
              <col style={{ width: '6.3%' }} />
              <col style={{ width: '6.3%' }} />
              <col style={{ width: '5.5%' }} />
              <col style={{ width: '6%' }} />
              <col style={{ width: '8.5%' }} />
            </colgroup>

            <tbody>
              {/* Top Title + Document Control Rows (Rows 1-4) */}
              <tr>
                <td
                  colSpan={9}
                  rowSpan={2}
                  className="border border-slate-800 px-3 py-1.5 text-center align-middle"
                >
                  <input
                    type="text"
                    value={meta.companyName}
                    onChange={(e) => onChangeMeta({ companyName: e.target.value })}
                    placeholder="YOUR COMPANY NAME"
                    className="w-full text-center text-xl font-bold tracking-wide text-slate-950 bg-transparent focus:outline-none focus:bg-blue-50/50 rounded px-1"
                  />
                </td>
                <td colSpan={3} className="border border-slate-800 px-2 py-0.5">
                  <div className="flex items-center gap-1 text-[10px]">
                    <span className="shrink-0 text-slate-700">Doc. No.</span>
                    <input
                      type="text"
                      value={meta.docNo}
                      onChange={(e) => onChangeMeta({ docNo: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono text-[10px]"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={3} className="border border-slate-800 px-2 py-0.5">
                  <div className="flex items-center gap-1 text-[10px]">
                    <span className="shrink-0 text-slate-700">Issue No.</span>
                    <input
                      type="text"
                      value={meta.issueNo}
                      onChange={(e) => onChangeMeta({ issueNo: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono text-[10px]"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td
                  colSpan={9}
                  rowSpan={2}
                  className="border border-slate-800 px-3 py-1 text-center align-middle"
                >
                  <input
                    type="text"
                    value={meta.reportTitle}
                    onChange={(e) => onChangeMeta({ reportTitle: e.target.value })}
                    placeholder="SAMPLE INSPECTION REPORT"
                    className="w-full text-center text-sm font-semibold tracking-wide text-slate-900 bg-transparent focus:outline-none focus:bg-blue-50/50 rounded px-1"
                  />
                </td>
                <td colSpan={3} className="border border-slate-800 px-2 py-0.5">
                  <div className="flex items-center gap-1 text-[10px]">
                    <span className="shrink-0 text-slate-700">Rev. No.</span>
                    <input
                      type="text"
                      value={meta.revNo}
                      onChange={(e) => onChangeMeta({ revNo: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono text-[10px]"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={3} className="border border-slate-800 px-2 py-0.5">
                  <div className="flex items-center gap-1 text-[10px]">
                    <span className="shrink-0 text-slate-700">Eff. Date:-</span>
                    <input
                      type="text"
                      value={meta.effDate}
                      onChange={(e) => onChangeMeta({ effDate: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono text-[10px]"
                    />
                  </div>
                </td>
              </tr>

              {/* Part & Vendor Metadata Rows (Rows 5-8) */}
              <tr>
                <td colSpan={5} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">PART NAME : -</span>
                    <input
                      type="text"
                      value={meta.partName}
                      onChange={(e) => onChangeMeta({ partName: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60"
                    />
                  </div>
                </td>
                <td colSpan={7} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">VENDOR NAME : -</span>
                    <input
                      type="text"
                      value={meta.vendorName}
                      onChange={(e) => onChangeMeta({ vendorName: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={5} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">
                      PART NUMBER/Rev. No. : -
                    </span>
                    <input
                      type="text"
                      value={meta.partNumberRev}
                      onChange={(e) => onChangeMeta({ partNumberRev: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
                <td colSpan={7} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">IN-VOICE NO. : -</span>
                    <input
                      type="text"
                      value={meta.invoiceNo}
                      onChange={(e) => onChangeMeta({ invoiceNo: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={5} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">PLANT CODE : -</span>
                    <input
                      type="text"
                      value={meta.plantCode}
                      onChange={(e) => onChangeMeta({ plantCode: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
                <td colSpan={7} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">QTY : -</span>
                    <input
                      type="text"
                      value={meta.qty}
                      onChange={(e) => onChangeMeta({ qty: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td colSpan={5} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">PAGE -</span>
                    <input
                      type="text"
                      value={meta.pageLabel}
                      onChange={(e) => onChangeMeta({ pageLabel: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
                <td colSpan={7} className="border border-slate-800 px-2 py-1.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">DATE : -</span>
                    <input
                      type="text"
                      value={meta.date}
                      onChange={(e) => onChangeMeta({ date: e.target.value })}
                      placeholder="DD/MM/YYYY"
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60 font-mono"
                    />
                  </div>
                </td>
              </tr>

              {/* Main 2-Row Table Header */}
              <tr className="bg-slate-50/80 font-semibold text-center text-[11px]">
                <th rowSpan={2} className="border border-slate-800 px-1 py-1.5 font-semibold">
                  Sr. No.
                </th>
                <th rowSpan={2} className="border border-slate-800 px-2 py-1.5 font-semibold">
                  Description
                </th>
                <th rowSpan={2} className="border border-slate-800 px-2 py-1.5 font-semibold">
                  Specification
                </th>
                <th rowSpan={2} className="border border-slate-800 px-1.5 py-1.5 font-semibold leading-tight">
                  Inspection Method
                </th>
                <th colSpan={5} className="border border-slate-800 px-1 py-1 font-semibold">
                  Sample
                </th>
                <th colSpan={2} className="border border-slate-800 px-1 py-1 font-semibold">
                  Status
                </th>
                <th rowSpan={2} className="border border-slate-800 px-1.5 py-1.5 font-semibold">
                  Remark
                </th>
              </tr>
              <tr className="bg-slate-50/80 font-semibold text-center text-[11px]">
                <th className="border border-slate-800 py-1 font-mono tabular-nums font-semibold">1</th>
                <th className="border border-slate-800 py-1 font-mono tabular-nums font-semibold">2</th>
                <th className="border border-slate-800 py-1 font-mono tabular-nums font-semibold">3</th>
                <th className="border border-slate-800 py-1 font-mono tabular-nums font-semibold">4</th>
                <th className="border border-slate-800 py-1 font-mono tabular-nums font-semibold">5</th>
                <th className="border border-slate-800 py-1 font-semibold">OK</th>
                <th className="border border-slate-800 py-1 font-semibold text-[10px]">NOT OK</th>
              </tr>

              {/* Populated Balloon Rows */}
              {sorted.map((b) => {
                const samples = b.samples ?? ['', '', '', '', ''];
                return (
                  <tr key={b.id} className="h-8 hover:bg-blue-50/25">
                    <td className="border border-slate-800 p-0 text-center">
                      <input
                        type="text"
                        value={b.label}
                        onChange={(e) =>
                          onUpdateBalloon(b.id, { label: e.target.value })
                        }
                        className="w-full h-8 text-center font-mono tabular-nums font-semibold bg-transparent focus:outline-none focus:bg-blue-50"
                      />
                    </td>
                    <td className="border border-slate-800 p-0">
                      <input
                        type="text"
                        value={b.description}
                        placeholder={b.type}
                        onChange={(e) =>
                          onUpdateBalloon(b.id, { description: e.target.value })
                        }
                        className="w-full h-8 px-2 bg-transparent focus:outline-none focus:bg-blue-50 placeholder:text-slate-300"
                      />
                    </td>
                    <td className="border border-slate-800 p-0">
                      <input
                        type="text"
                        value={formatBalloonSpecification(b)}
                        onChange={(e) =>
                          onUpdateBalloon(b.id, {
                            nominal: e.target.value,
                            tolerance: '',
                          })
                        }
                        placeholder="e.g. 95 ±0.2"
                        className="w-full h-8 px-2 font-mono tabular-nums bg-transparent focus:outline-none focus:bg-blue-50 placeholder:text-slate-300"
                      />
                    </td>
                    <td className="border border-slate-800 p-0">
                      <input
                        type="text"
                        list="inspection-methods-list"
                        value={b.inspectionMethod}
                        onChange={(e) =>
                          onUpdateBalloon(b.id, { inspectionMethod: e.target.value })
                        }
                        placeholder="Vernier / CMM"
                        className="w-full h-8 px-1.5 text-center bg-transparent focus:outline-none focus:bg-blue-50 placeholder:text-slate-300"
                      />
                    </td>
                    {[0, 1, 2, 3, 4].map((sIdx) => (
                      <td key={sIdx} className="border border-slate-800 p-0">
                        <input
                          type="text"
                          value={samples[sIdx] ?? ''}
                          onChange={(e) => handleSampleChange(b, sIdx, e.target.value)}
                          className="w-full h-8 px-1 text-center font-mono tabular-nums bg-transparent focus:outline-none focus:bg-blue-50"
                        />
                      </td>
                    ))}
                    <td className="border border-slate-800 p-0 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateBalloon(b.id, {
                            status: b.status === 'OK' ? '' : 'OK',
                          })
                        }
                        aria-label={`Mark item ${b.label} OK`}
                        className={`w-full h-8 text-[11px] font-bold transition-colors cursor-pointer ${
                          b.status === 'OK'
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'hover:bg-slate-50 text-transparent'
                        }`}
                      >
                        {b.status === 'OK' ? 'OK' : '-'}
                      </button>
                    </td>
                    <td className="border border-slate-800 p-0 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateBalloon(b.id, {
                            status: b.status === 'NOT OK' ? '' : 'NOT OK',
                          })
                        }
                        aria-label={`Mark item ${b.label} NOT OK`}
                        className={`w-full h-8 text-[10px] font-bold transition-colors cursor-pointer ${
                          b.status === 'NOT OK'
                            ? 'bg-red-50 text-red-700'
                            : 'hover:bg-slate-50 text-transparent'
                        }`}
                      >
                        {b.status === 'NOT OK' ? 'NOT OK' : '-'}
                      </button>
                    </td>
                    <td className="border border-slate-800 p-0">
                      <input
                        type="text"
                        value={b.remarks}
                        onChange={(e) =>
                          onUpdateBalloon(b.id, { remarks: e.target.value })
                        }
                        className="w-full h-8 px-1.5 bg-transparent focus:outline-none focus:bg-blue-50"
                      />
                    </td>
                  </tr>
                );
              })}

              {/* Standard Blank Padding Rows matching the full report sheet */}
              {Array.from({ length: blankRowCount }).map((_, idx) => (
                <tr key={`blank_${idx}`} className="h-7">
                  {Array.from({ length: 12 }).map((__, colIdx) => (
                    <td key={colIdx} className="border border-slate-800" />
                  ))}
                </tr>
              ))}

              {/* Bottom Sign-Off Footer Row */}
              <tr>
                <td colSpan={4} className="border border-slate-800 px-2.5 py-2.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">INSPECTED BY</span>
                    <input
                      type="text"
                      value={meta.inspectedBy}
                      onChange={(e) => onChangeMeta({ inspectedBy: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60"
                    />
                  </div>
                </td>
                <td colSpan={4} className="border border-slate-800 px-2.5 py-2.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">CHECKED BY</span>
                    <input
                      type="text"
                      value={meta.checkedBy}
                      onChange={(e) => onChangeMeta({ checkedBy: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60"
                    />
                  </div>
                </td>
                <td colSpan={4} className="border border-slate-800 px-2.5 py-2.5">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <span className="shrink-0 font-medium text-slate-800">APPROVED BY</span>
                    <input
                      type="text"
                      value={meta.approvedBy}
                      onChange={(e) => onChangeMeta({ approvedBy: e.target.value })}
                      className="w-full min-w-0 bg-transparent focus:outline-none focus:bg-blue-50/60"
                    />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
