import { ListOrdered, Trash2, Minus, Plus, CheckSquare, FileSpreadsheet } from 'lucide-react';
import {
  POINTER_PRESETS,
  QA_COLORS,
  type PointerPreset,
  type ToolMode,
} from '../types/drawing';

interface OptionsBarProps {
  activeTool: ToolMode;
  nextNumber: number;
  onChangeNextNumber: (n: number) => void;
  activePreset: PointerPreset;
  onChangePreset: (preset: PointerPreset) => void;
  activeColor: string;
  onChangeColor: (color: string) => void;
  activeSize: number;
  sizeLabel: string;
  onChangeSize: (size: number) => void;
  selectedCount: number;
  pageBalloonCount: number;
  onSelectAllPage: () => void;
  onRenumber: () => void;
  onClearPage: () => void;
  onOpenInspectionSheet: () => void;
}

export function OptionsBar({
  activeTool,
  nextNumber,
  onChangeNextNumber,
  activePreset,
  onChangePreset,
  activeColor,
  onChangeColor,
  activeSize,
  sizeLabel,
  onChangeSize,
  selectedCount,
  pageBalloonCount,
  onSelectAllPage,
  onRenumber,
  onClearPage,
  onOpenInspectionSheet,
}: OptionsBarProps) {
  return (
    <div className="h-12 bg-white border-b border-slate-200 px-4 flex items-center justify-between gap-4 shrink-0 overflow-x-auto">
      <div className="flex items-center gap-3.5 shrink-0">
        {/* Next Balloon # */}
        <label className="flex items-center gap-2 text-xs text-slate-600 shrink-0">
          <span className="font-medium whitespace-nowrap">Next #</span>
          <input
            type="number"
            min={1}
            max={9999}
            value={nextNumber}
            onChange={(e) => {
              const v = parseInt(e.target.value, 10);
              if (!Number.isNaN(v) && v >= 1) onChangeNextNumber(v);
            }}
            className="w-15 h-8 px-2 text-xs font-mono tabular-nums font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-blue-600 focus:bg-white"
          />
        </label>

        <div className="h-5 border-l border-slate-200" />

        {/* Unified Pointer & Shape Selector (Teardrop default) */}
        <label className="flex items-center gap-2 text-xs text-slate-600 shrink-0">
          <span className="font-medium whitespace-nowrap">Pointer</span>
          <select
            value={activePreset}
            onChange={(e) => onChangePreset(e.target.value as PointerPreset)}
            className="h-8 px-2.5 text-xs font-medium text-slate-900 bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:border-blue-600 cursor-pointer"
          >
            {POINTER_PRESETS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </label>

        <div className="h-5 border-l border-slate-200" />

        {/* Color Swatches */}
        <div className="flex items-center gap-1.5 shrink-0" role="group" aria-label="Pointer color">
          {QA_COLORS.map((c) => {
            const selected = activeColor.toLowerCase() === c.value.toLowerCase();
            return (
              <button
                key={c.value}
                type="button"
                title={c.name}
                aria-label={c.name}
                onClick={() => onChangeColor(c.value)}
                className={`w-5.5 h-5.5 rounded-full flex items-center justify-center transition-transform cursor-pointer ${
                  selected ? 'ring-2 ring-offset-2 ring-slate-900 scale-105' : 'hover:scale-105'
                }`}
                style={{ backgroundColor: c.value }}
              />
            );
          })}
        </div>

        <div className="h-5 border-l border-slate-200" />

        {/* Size Controls (applies live to selected pointer/shape or default) */}
        <div className="flex items-center gap-1.5 text-xs text-slate-600 shrink-0">
          <span className="font-medium whitespace-nowrap">{sizeLabel}</span>
          <button
            type="button"
            title="Decrease Size ([)"
            aria-label="Decrease Size"
            onClick={() => onChangeSize(Math.max(10, activeSize - 2))}
            className="w-6 h-6 rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer"
          >
            <Minus className="w-3 h-3" />
          </button>
          <input
            type="range"
            min={10}
            max={72}
            step={1}
            value={activeSize}
            onChange={(e) => onChangeSize(Number(e.target.value))}
            aria-label="Pointer Size"
            className="w-20 accent-blue-700 cursor-pointer"
          />
          <button
            type="button"
            title="Increase Size (])"
            aria-label="Increase Size"
            onClick={() => onChangeSize(Math.min(72, activeSize + 2))}
            className="w-6 h-6 rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-700 cursor-pointer"
          >
            <Plus className="w-3 h-3" />
          </button>
          <span className="w-8 text-right font-mono tabular-nums text-[11px] text-slate-500">
            {Math.round(activeSize)}px
          </span>
        </div>
      </div>

      {/* Right contextual utilities */}
      <div className="flex items-center gap-2 shrink-0">
        {selectedCount > 1 ? (
          <span className="text-xs font-medium text-blue-700 font-mono tabular-nums whitespace-nowrap mr-1">
            {selectedCount} selected
          </span>
        ) : (
          (activeTool === 'balloon' || activeTool === 'select') && (
            <span className="hidden 2xl:inline text-xs text-slate-500 whitespace-nowrap mr-1">
              Ctrl+A select all · Ctrl+Click multi · Ctrl+Drag copy
            </span>
          )
        )}

        <button
          type="button"
          onClick={onOpenInspectionSheet}
          title="Open formatted Sample Inspection Report sheet"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md hover:bg-emerald-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>Inspection Sheet</span>
        </button>

        <button
          type="button"
          disabled={pageBalloonCount === 0}
          onClick={onSelectAllPage}
          title="Select all pointers on this page (Ctrl+A)"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <CheckSquare className="w-3.5 h-3.5" />
          <span>Select All</span>
        </button>

        <button
          type="button"
          disabled={pageBalloonCount === 0}
          onClick={onRenumber}
          title="Renumber all balloons sequentially starting at 1"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-md hover:bg-slate-100 disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <ListOrdered className="w-3.5 h-3.5" />
          <span>Renumber</span>
        </button>

        <button
          type="button"
          disabled={pageBalloonCount === 0}
          onClick={onClearPage}
          title="Remove all balloons and markups on this page"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-red-700 bg-white border border-slate-200 rounded-md hover:bg-red-50 hover:border-red-200 disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear Page</span>
        </button>
      </div>
    </div>
  );
}
