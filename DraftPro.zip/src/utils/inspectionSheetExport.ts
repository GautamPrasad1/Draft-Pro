import { jsPDF } from 'jspdf';
import type { BalloonItem, InspectionReportMeta } from '../types/drawing';

function stripExtension(name: string): string {
  return name.replace(/\.[^/.]+$/, '');
}

export function sortBalloonsForReport(balloons: BalloonItem[]): BalloonItem[] {
  return [...balloons].sort((a, b) => {
    if (a.pageIndex !== b.pageIndex) return a.pageIndex - b.pageIndex;
    const na = parseFloat(a.label);
    const nb = parseFloat(b.label);
    if (!Number.isNaN(na) && !Number.isNaN(nb) && na !== nb) return na - nb;
    return a.label.localeCompare(b.label);
  });
}

export function formatBalloonSpecification(b: BalloonItem): string {
  const parts = [b.nominal.trim(), b.tolerance.trim()].filter(Boolean);
  return parts.join(' ');
}

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// --- Minimal zero-dependency ZIP Store (method 0) builder for valid OOXML .xlsx ---
const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function buildZip(entries: { name: string; content: string }[]): Blob {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBytes = encoder.encode(entry.name);
    const dataBytes = encoder.encode(entry.content);
    const crc = crc32(dataBytes);
    const size = dataBytes.length;

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0, true);
    lv.setUint16(8, 0, true); // store
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, dataBytes);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  }

  const centralSize = centralParts.reduce((sum, p) => sum + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalLen = offset + centralSize + eocd.length;
  const out = new Uint8Array(new ArrayBuffer(totalLen));
  let pos = 0;
  for (const part of localParts) {
    out.set(part, pos);
    pos += part.length;
  }
  for (const part of centralParts) {
    out.set(part, pos);
    pos += part.length;
  }
  out.set(eocd, pos);

  return new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
}

const COLS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'] as const;

function makeCellXml(colIdx: number, rowNum: number, value: string, styleId: number): string {
  const ref = `${COLS[colIdx]}${rowNum}`;
  if (!value) {
    return `<c r="${ref}" s="${styleId}"/>`;
  }
  return `<c r="${ref}" t="inlineStr" s="${styleId}"><is><t>${escapeXml(value)}</t></is></c>`;
}

/**
 * Generates a real, fully formatted OOXML Excel (.xlsx) workbook matching the
 * exact Sample Inspection Report layout with merged headers, borders, and A4 print fit.
 */
export function exportInspectionSheetXLSX(
  fileName: string,
  balloons: BalloonItem[],
  meta: InspectionReportMeta
): void {
  const sorted = sortBalloonsForReport(balloons);
  const minDataRows = 25;
  const totalDataRows = Math.max(minDataRows, sorted.length);
  const footerRow = 11 + totalDataRows;

  // Styles:
  // 0: default
  // 1: Company Name (18pt bold centered, thin border)
  // 2: Report Title (13pt centered, thin border)
  // 3: Doc Control right box (8.5pt left, thin border)
  // 4: Metadata left/right row (9.5pt left, thin border)
  // 5: Table Header (10pt bold centered wrap, thin border)
  // 6: Data cell centered (9.5pt centered, thin border)
  // 7: Data cell left (9.5pt left, thin border)
  // 8: Footer sign-off (9.5pt left, thin border)
  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="6">
    <font><sz val="10"/><name val="Calibri"/></font>
    <font><b/><sz val="18"/><name val="Calibri"/></font>
    <font><sz val="13"/><name val="Calibri"/></font>
    <font><sz val="8.5"/><name val="Calibri"/></font>
    <font><sz val="9.5"/><name val="Calibri"/></font>
    <font><b/><sz val="9.5"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FF000000"/></left>
      <right style="thin"><color rgb="FF000000"/></right>
      <top style="thin"><color rgb="FF000000"/></top>
      <bottom style="thin"><color rgb="FF000000"/></bottom>
      <diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="9">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
    <xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
    <xf numFmtId="0" fontId="5" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
  </cellXfs>
</styleSheet>`;

  const rowsXml: string[] = [];

  const pushFullRow = (
    rowNum: number,
    height: number,
    values: Record<number, { val: string; s: number }>,
    defaultStyle: number
  ) => {
    const cells: string[] = [];
    for (let c = 0; c < 12; c++) {
      const cell = values[c];
      cells.push(makeCellXml(c, rowNum, cell?.val ?? '', cell?.s ?? defaultStyle));
    }
    rowsXml.push(`<row r="${rowNum}" ht="${height}" customHeight="1">${cells.join('')}</row>`);
  };

  // Rows 1-4: Title + Doc Control block
  pushFullRow(
    1,
    18,
    {
      0: { val: meta.companyName || 'YOUR COMPANY NAME', s: 1 },
      9: { val: `Doc. No. ${meta.docNo}`.trim(), s: 3 },
    },
    1
  );
  pushFullRow(
    2,
    18,
    {
      9: { val: `Issue No. ${meta.issueNo}`.trim(), s: 3 },
    },
    1
  );
  pushFullRow(
    3,
    16,
    {
      0: { val: meta.reportTitle || 'SAMPLE INSPECTION REPORT', s: 2 },
      9: { val: `Rev. No. ${meta.revNo}`.trim(), s: 3 },
    },
    2
  );
  pushFullRow(
    4,
    16,
    {
      9: { val: `Eff. Date:- ${meta.effDate}`.trim(), s: 3 },
    },
    2
  );

  // Rows 5-8: Part & Lot Metadata
  pushFullRow(
    5,
    20,
    {
      0: { val: `PART NAME : - ${meta.partName}`.trimEnd(), s: 4 },
      5: { val: `VENDOR NAME : - ${meta.vendorName}`.trimEnd(), s: 4 },
    },
    4
  );
  pushFullRow(
    6,
    20,
    {
      0: { val: `PART NUMBER/Rev. No. : - ${meta.partNumberRev}`.trimEnd(), s: 4 },
      5: { val: `IN-VOICE NO. : - ${meta.invoiceNo}`.trimEnd(), s: 4 },
    },
    4
  );
  pushFullRow(
    7,
    20,
    {
      0: { val: `PLANT CODE : - ${meta.plantCode}`.trimEnd(), s: 4 },
      5: { val: `QTY : - ${meta.qty}`.trimEnd(), s: 4 },
    },
    4
  );
  pushFullRow(
    8,
    20,
    {
      0: { val: `PAGE - ${meta.pageLabel}`.trimEnd(), s: 4 },
      5: { val: `DATE : - ${meta.date}`.trimEnd(), s: 4 },
    },
    4
  );

  // Rows 9-10: Two-row Table Header
  pushFullRow(
    9,
    18,
    {
      0: { val: 'Sr. No.', s: 5 },
      1: { val: 'Description', s: 5 },
      2: { val: 'Specification', s: 5 },
      3: { val: 'Inspection Method', s: 5 },
      4: { val: 'Sample', s: 5 },
      9: { val: 'Status', s: 5 },
      11: { val: 'Remark', s: 5 },
    },
    5
  );
  pushFullRow(
    10,
    18,
    {
      4: { val: '1', s: 5 },
      5: { val: '2', s: 5 },
      6: { val: '3', s: 5 },
      7: { val: '4', s: 5 },
      8: { val: '5', s: 5 },
      9: { val: 'OK', s: 5 },
      10: { val: 'NOT OK', s: 5 },
    },
    5
  );

  // Data rows (Rows 11 .. 10 + totalDataRows)
  for (let i = 0; i < totalDataRows; i++) {
    const r = 11 + i;
    const b = sorted[i];
    if (b) {
      const samples = b.samples ?? ['', '', '', '', ''];
      pushFullRow(
        r,
        21,
        {
          0: { val: b.label, s: 6 },
          1: { val: b.description || b.type || '', s: 7 },
          2: { val: formatBalloonSpecification(b), s: 7 },
          3: { val: b.inspectionMethod || '', s: 6 },
          4: { val: samples[0] ?? '', s: 6 },
          5: { val: samples[1] ?? '', s: 6 },
          6: { val: samples[2] ?? '', s: 6 },
          7: { val: samples[3] ?? '', s: 6 },
          8: { val: samples[4] ?? '', s: 6 },
          9: { val: b.status === 'OK' ? 'OK' : '', s: 6 },
          10: { val: b.status === 'NOT OK' ? 'NOT OK' : '', s: 6 },
          11: { val: b.remarks || '', s: 7 },
        },
        6
      );
    } else {
      pushFullRow(r, 21, {}, 6);
    }
  }

  // Footer Row: INSPECTED BY | CHECKED BY | APPROVED BY
  pushFullRow(
    footerRow,
    26,
    {
      0: { val: `INSPECTED BY${meta.inspectedBy ? ': ' + meta.inspectedBy : ''}`, s: 8 },
      4: { val: `CHECKED BY${meta.checkedBy ? ': ' + meta.checkedBy : ''}`, s: 8 },
      8: { val: `APPROVED BY${meta.approvedBy ? ': ' + meta.approvedBy : ''}`, s: 8 },
    },
    8
  );

  const merges = [
    'A1:I2',
    'A3:I4',
    'J1:L1',
    'J2:L2',
    'J3:L3',
    'J4:L4',
    'A5:E5',
    'F5:L5',
    'A6:E6',
    'F6:L6',
    'A7:E7',
    'F7:L7',
    'A8:E8',
    'F8:L8',
    'A9:A10',
    'B9:B10',
    'C9:C10',
    'D9:D10',
    'E9:I9',
    'J9:K9',
    'L9:L10',
    `A${footerRow}:D${footerRow}`,
    `E${footerRow}:H${footerRow}`,
    `I${footerRow}:L${footerRow}`,
  ];

  const colWidths = [7, 20, 21, 15, 8.5, 8.5, 8.5, 8.5, 8.5, 7.5, 8.5, 14];
  const colsXml = colWidths
    .map(
      (w, idx) =>
        `<col min="${idx + 1}" max="${idx + 1}" width="${w}" customWidth="1"/>`
    )
    .join('');

  const sheetXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>
  <cols>${colsXml}</cols>
  <sheetData>${rowsXml.join('')}</sheetData>
  <mergeCells count="${merges.length}">${merges
    .map((m) => `<mergeCell ref="${m}"/>`)
    .join('')}</mergeCells>
  <pageMargins left="0.25" right="0.25" top="0.3" bottom="0.3" header="0.2" footer="0.2"/>
  <pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>
</worksheet>`;

  const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`;

  const relsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`;

  const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Inspection Report" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`;

  const workbookRelsXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const blob = buildZip([
    { name: '[Content_Types].xml', content: contentTypesXml },
    { name: '_rels/.rels', content: relsXml },
    { name: 'xl/workbook.xml', content: workbookXml },
    { name: 'xl/_rels/workbook.xml.rels', content: workbookRelsXml },
    { name: 'xl/styles.xml', content: stylesXml },
    { name: 'xl/worksheets/sheet1.xml', content: sheetXml },
  ]);

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${stripExtension(fileName)}_sample_inspection_report.xlsx`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Generates an exact-format A4 Printable PDF matching the Sample Inspection Report layout.
 */
export function exportInspectionSheetPDF(
  fileName: string,
  balloons: BalloonItem[],
  meta: InspectionReportMeta
): void {
  const sorted = sortBalloonsForReport(balloons);
  const rowsPerPage = 26;
  const pageCount = Math.max(1, Math.ceil(sorted.length / rowsPerPage));

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const marginX = 7;
  const startY = 7;
  const totalW = 210 - marginX * 2; // 196mm

  // 12 column widths summing to 196mm
  const colW = [10, 30, 31, 21, 12.5, 12.5, 12.5, 12.5, 12.5, 11, 13, 17.5];
  const colX: number[] = [marginX];
  for (let i = 0; i < colW.length; i++) {
    colX.push(colX[i] + colW[i]);
  }

  const drawTextCell = (
    text: string,
    x: number,
    y: number,
    w: number,
    h: number,
    opts?: { align?: 'left' | 'center'; size?: number; bold?: boolean }
  ) => {
    const size = opts?.size ?? 7.5;
    const align = opts?.align ?? 'center';
    pdf.setFont('helvetica', opts?.bold ? 'bold' : 'normal');
    pdf.setFontSize(size);
    const maxW = Math.max(2, w - 2.4);
    const clipped = pdf.splitTextToSize(text || '', maxW)[0] ?? '';
    const tx = align === 'center' ? x + w / 2 : x + 1.5;
    const ty = y + h / 2 + size * 0.13;
    pdf.text(clipped, tx, ty, { align });
  };

  for (let p = 0; p < pageCount; p++) {
    if (p > 0) pdf.addPage('a4', 'portrait');

    pdf.setDrawColor(0, 0, 0);
    pdf.setTextColor(0, 0, 0);
    pdf.setLineWidth(0.25);

    let y = startY;

    // Top Title + Doc Control Block (18mm height)
    const docBoxX = colX[9];
    const docBoxW = colX[12] - docBoxX;
    const titleW = docBoxX - marginX;
    const docRowH = 4.5;
    const titleBlockH = docRowH * 4;

    pdf.rect(marginX, y, titleW, titleBlockH);
    drawTextCell(meta.companyName || 'YOUR COMPANY NAME', marginX, y + 1, titleW, 9.5, {
      align: 'center',
      size: 14,
      bold: true,
    });
    drawTextCell(
      meta.reportTitle || 'SAMPLE INSPECTION REPORT',
      marginX,
      y + 10.5,
      titleW,
      7,
      { align: 'center', size: 10, bold: false }
    );

    const docLines = [
      `Doc. No. ${meta.docNo}`,
      `Issue No. ${meta.issueNo}`,
      `Rev. No. ${meta.revNo}`,
      `Eff. Date:- ${meta.effDate}`,
    ];
    docLines.forEach((line, idx) => {
      const ry = y + idx * docRowH;
      pdf.rect(docBoxX, ry, docBoxW, docRowH);
      drawTextCell(line.trim(), docBoxX, ry, docBoxW, docRowH, {
        align: 'left',
        size: 6.5,
      });
    });

    y += titleBlockH;

    // Part & Lot Metadata Block (4 rows x 6.5mm)
    const metaRowH = 6.5;
    const leftHalfW = colX[5] - marginX;
    const rightHalfW = colX[12] - colX[5];
    const pageStr = pageCount > 1 ? `${p + 1} OF ${pageCount}` : meta.pageLabel || '1 OF 1';

    const metaRows: [string, string][] = [
      [`PART NAME : - ${meta.partName}`, `VENDOR NAME : - ${meta.vendorName}`],
      [
        `PART NUMBER/Rev. No. : - ${meta.partNumberRev}`,
        `IN-VOICE NO. : - ${meta.invoiceNo}`,
      ],
      [`PLANT CODE : - ${meta.plantCode}`, `QTY : - ${meta.qty}`],
      [`PAGE - ${pageStr}`, `DATE : - ${meta.date}`],
    ];

    metaRows.forEach(([leftText, rightText]) => {
      pdf.rect(marginX, y, leftHalfW, metaRowH);
      pdf.rect(colX[5], y, rightHalfW, metaRowH);
      drawTextCell(leftText.trimEnd(), marginX, y, leftHalfW, metaRowH, {
        align: 'left',
        size: 7.5,
      });
      drawTextCell(rightText.trimEnd(), colX[5], y, rightHalfW, metaRowH, {
        align: 'left',
        size: 7.5,
      });
      y += metaRowH;
    });

    // Two-row Table Header (11mm total = 5.5 + 5.5)
    const hdrH1 = 5.2;
    const hdrH2 = 5.8;
    const hdrTotal = hdrH1 + hdrH2;

    // Merged rowspan=2 columns: Sr. No., Description, Specification, Inspection Method, Remark
    pdf.rect(colX[0], y, colW[0], hdrTotal);
    drawTextCell('Sr. No.', colX[0], y, colW[0], hdrTotal, { size: 7.5, bold: true });

    pdf.rect(colX[1], y, colW[1], hdrTotal);
    drawTextCell('Description', colX[1], y, colW[1], hdrTotal, { size: 7.5, bold: true });

    pdf.rect(colX[2], y, colW[2], hdrTotal);
    drawTextCell('Specification', colX[2], y, colW[2], hdrTotal, { size: 7.5, bold: true });

    pdf.rect(colX[3], y, colW[3], hdrTotal);
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(7.2);
    pdf.text('Inspection', colX[3] + colW[3] / 2, y + 4.5, { align: 'center' });
    pdf.text('Method', colX[3] + colW[3] / 2, y + 8.3, { align: 'center' });

    // Sample colspan=5
    const sampleW = colX[9] - colX[4];
    pdf.rect(colX[4], y, sampleW, hdrH1);
    drawTextCell('Sample', colX[4], y, sampleW, hdrH1, { size: 7.5, bold: true });
    for (let s = 0; s < 5; s++) {
      pdf.rect(colX[4 + s], y + hdrH1, colW[4 + s], hdrH2);
      drawTextCell(String(s + 1), colX[4 + s], y + hdrH1, colW[4 + s], hdrH2, {
        size: 7.5,
        bold: true,
      });
    }

    // Status colspan=2
    const statusW = colX[11] - colX[9];
    pdf.rect(colX[9], y, statusW, hdrH1);
    drawTextCell('Status', colX[9], y, statusW, hdrH1, { size: 7.5, bold: true });
    pdf.rect(colX[9], y + hdrH1, colW[9], hdrH2);
    drawTextCell('OK', colX[9], y + hdrH1, colW[9], hdrH2, { size: 7, bold: true });
    pdf.rect(colX[10], y + hdrH1, colW[10], hdrH2);
    drawTextCell('NOT OK', colX[10], y + hdrH1, colW[10], hdrH2, { size: 6.8, bold: true });

    // Remark
    pdf.rect(colX[11], y, colW[11], hdrTotal);
    drawTextCell('Remark', colX[11], y, colW[11], hdrTotal, { size: 7.5, bold: true });

    y += hdrTotal;

    // 26 Data Rows filling the A4 sheet cleanly
    const footerH = 9.5;
    const availDataH = 290 - footerH - y;
    const rowH = availDataH / rowsPerPage;

    for (let i = 0; i < rowsPerPage; i++) {
      const b = sorted[p * rowsPerPage + i];
      for (let c = 0; c < 12; c++) {
        pdf.rect(colX[c], y, colW[c], rowH);
      }

      if (b) {
        const samples = b.samples ?? ['', '', '', '', ''];
        drawTextCell(b.label, colX[0], y, colW[0], rowH, { align: 'center', size: 7.5 });
        drawTextCell(b.description || b.type || '', colX[1], y, colW[1], rowH, {
          align: 'left',
          size: 7.2,
        });
        drawTextCell(formatBalloonSpecification(b), colX[2], y, colW[2], rowH, {
          align: 'left',
          size: 7.2,
        });
        drawTextCell(b.inspectionMethod || '', colX[3], y, colW[3], rowH, {
          align: 'center',
          size: 7,
        });
        for (let s = 0; s < 5; s++) {
          drawTextCell(samples[s] ?? '', colX[4 + s], y, colW[4 + s], rowH, {
            align: 'center',
            size: 7,
          });
        }
        if (b.status === 'OK') {
          drawTextCell('OK', colX[9], y, colW[9], rowH, {
            align: 'center',
            size: 7,
            bold: true,
          });
        } else if (b.status === 'NOT OK') {
          drawTextCell('NOT OK', colX[10], y, colW[10], rowH, {
            align: 'center',
            size: 6.5,
            bold: true,
          });
        }
        drawTextCell(b.remarks || '', colX[11], y, colW[11], rowH, {
          align: 'left',
          size: 7,
        });
      }
      y += rowH;
    }

    // Bottom Sign-off Footer (3 equal sections)
    const thirdW = totalW / 3;
    pdf.rect(marginX, y, totalW, footerH);
    drawTextCell(
      `INSPECTED BY${meta.inspectedBy ? ': ' + meta.inspectedBy : ''}`,
      marginX,
      y,
      thirdW,
      footerH,
      { align: 'left', size: 7.5 }
    );
    drawTextCell(
      `CHECKED BY${meta.checkedBy ? ': ' + meta.checkedBy : ''}`,
      marginX + thirdW,
      y,
      thirdW,
      footerH,
      { align: 'left', size: 7.5 }
    );
    drawTextCell(
      `APPROVED BY${meta.approvedBy ? ': ' + meta.approvedBy : ''}`,
      marginX + thirdW * 2,
      y,
      thirdW,
      footerH,
      { align: 'left', size: 7.5 }
    );
  }

  pdf.save(`${stripExtension(fileName)}_sample_inspection_report.pdf`);
}
