import type {
  BalloonItem,
  BalloonShape,
  DrawingAnnotation,
  DrawingPage,
} from '../types/drawing';

export interface Point {
  x: number;
  y: number;
}

export const DRAWING_BRAND_STAMP_TEXT = 'BY DRAFT PRO MANUFACTURING SUITE';

export interface DrawingBrandStampMetrics {
  fontSize: number;
  logoSize: number;
  gap: number;
  marginX: number;
  marginY: number;
}

export function getDrawingBrandStampMetrics(
  sheetW: number,
  sheetH: number
): DrawingBrandStampMetrics {
  const refDim = Math.min(sheetW, sheetH);
  // Strictly proportional CAD outer-margin scale so 5600px print exports match live view identically
  const fontSize = Math.max(8, Math.round(refDim * 0.0082));
  const logoSize = Math.max(18, Math.round(fontSize * 2.1));
  const gap = Math.max(5, Math.round(fontSize * 0.55));
  const marginX = Math.max(10, Math.round(refDim * 0.012));
  const marginY = Math.max(2, Math.round(refDim * 0.0025));
  return { fontSize, logoSize, gap, marginX, marginY };
}

function drawBrandLogoOnCanvas(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  size: number
) {
  ctx.save();
  ctx.translate(x, y);
  const scale = size / 44;
  ctx.scale(scale, scale);

  ctx.fillStyle = '#0F172A';
  ctx.fill(new Path2D('M8 2H36L42 8V36L36 42H8L2 36V8L8 2Z'));

  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 1.2;
  ctx.stroke(new Path2D('M8.5 3.5H35.5L40.5 8.5V35.5L35.5 40.5H8.5L3.5 35.5V8.5L8.5 3.5Z'));

  ctx.save();
  ctx.globalAlpha *= 0.7;
  ctx.strokeStyle = '#60A5FA';
  ctx.lineWidth = 1.4;
  ctx.lineCap = 'square';
  ctx.stroke(new Path2D('M8 12V8H12M32 8H36V12M36 32V36H32M12 36H8V32'));
  ctx.restore();

  ctx.fillStyle = '#2563EB';
  ctx.fill(new Path2D('M11 22L21.5 14.3A9.5 9.5 0 1 1 21.5 29.7L11 22Z'));

  ctx.beginPath();
  ctx.arc(26.2, 22, 6.3, 0, Math.PI * 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();

  ctx.fillStyle = '#0F172A';
  ctx.fill(
    new Path2D(
      'M24 18.2H26.4C28.45 18.2 29.8 19.75 29.8 22C29.8 24.25 28.45 25.8 26.4 25.8H24V18.2ZM25.65 19.65V24.35H26.35C27.5 24.35 28.15 23.5 28.15 22C28.15 20.5 27.5 19.65 26.35 19.65H25.65Z'
    )
  );

  ctx.restore();
}

export function getShapePolygonPoints(
  shape: BalloonShape,
  cx: number,
  cy: number,
  r: number
): Point[] {
  if (shape === 'square') {
    return [
      { x: cx - r, y: cy - r },
      { x: cx + r, y: cy - r },
      { x: cx + r, y: cy + r },
      { x: cx - r, y: cy + r },
    ];
  }
  if (shape === 'diamond') {
    const d = r * 1.18;
    return [
      { x: cx, y: cy - d },
      { x: cx + d, y: cy },
      { x: cx, y: cy + d },
      { x: cx - d, y: cy },
    ];
  }
  if (shape === 'hexagon') {
    const pts: Point[] = [];
    const hr = r * 1.08;
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i - Math.PI / 6;
      pts.push({
        x: cx + hr * Math.cos(angle),
        y: cy + hr * Math.sin(angle),
      });
    }
    return pts;
  }
  return [];
}

/**
 * Computes a filled triangular directional pointer (automotive/QA wedge style)
 * seamlessly attached to the rim of the balloon pointing toward (targetX, targetY).
 */
export function getWedgePoints(
  cx: number,
  cy: number,
  tx: number,
  ty: number,
  radius: number
): Point[] | null {
  const dx = tx - cx;
  const dy = ty - cy;
  const dist = Math.hypot(dx, dy);
  if (dist <= radius * 1.08) return null;

  const angle = Math.atan2(dy, dx);
  const spread = Math.min(0.42, Math.max(0.22, (radius / dist) * 0.65));
  const attachR = radius * 0.94;

  const left: Point = {
    x: cx + attachR * Math.cos(angle - spread),
    y: cy + attachR * Math.sin(angle - spread),
  };
  const right: Point = {
    x: cx + attachR * Math.cos(angle + spread),
    y: cy + attachR * Math.sin(angle + spread),
  };

  return [left, { x: tx, y: ty }, right];
}

export interface TeardropGeometry {
  cx: number;
  cy: number;
  outerRadius: number;
  tip: Point;
  t1: Point;
  t2: Point;
  startAngle: number;
  endAngle: number;
  outerSvgPath: string;
}

/**
 * Computes exact mathematical tangent lines from pointer tip (tx, ty) to a circle
 * of radius outerRadius centered at (cx, cy), forming a seamless teardrop pin.
 */
export function getTangentTeardropGeometry(
  cx: number,
  cy: number,
  tx: number,
  ty: number,
  outerRadius: number
): TeardropGeometry | null {
  const dx = tx - cx;
  const dy = ty - cy;
  const dist = Math.hypot(dx, dy);
  if (dist <= outerRadius + 1) return null;

  const theta = Math.atan2(dy, dx);
  const alpha = Math.acos(Math.min(1, outerRadius / dist));

  const startAngle = theta + alpha;
  const endAngle = theta - alpha + Math.PI * 2;

  const t1: Point = {
    x: cx + outerRadius * Math.cos(startAngle),
    y: cy + outerRadius * Math.sin(startAngle),
  };
  const t2: Point = {
    x: cx + outerRadius * Math.cos(theta - alpha),
    y: cy + outerRadius * Math.sin(theta - alpha),
  };

  const outerSvgPath = [
    `M ${tx.toFixed(2)} ${ty.toFixed(2)}`,
    `L ${t1.x.toFixed(2)} ${t1.y.toFixed(2)}`,
    `A ${outerRadius.toFixed(2)} ${outerRadius.toFixed(2)} 0 1 1 ${t2.x.toFixed(2)} ${t2.y.toFixed(2)}`,
    'Z',
  ].join(' ');

  return {
    cx,
    cy,
    outerRadius,
    tip: { x: tx, y: ty },
    t1,
    t2,
    startAngle,
    endAngle,
    outerSvgPath,
  };
}

export function circleSvgSubpath(cx: number, cy: number, r: number): string {
  const x0 = cx - r;
  return `M ${x0.toFixed(2)} ${cy.toFixed(2)} A ${r.toFixed(2)} ${r.toFixed(2)} 0 1 0 ${(cx + r).toFixed(2)} ${cy.toFixed(2)} A ${r.toFixed(2)} ${r.toFixed(2)} 0 1 0 ${x0.toFixed(2)} ${cy.toFixed(2)} Z`;
}

/**
 * Computes leader line start/end and arrowhead triangle points for arrow pointer style.
 */
export function getLeaderArrowGeometry(
  cx: number,
  cy: number,
  tx: number,
  ty: number,
  radius: number,
  strokeWidth: number
): { start: Point; tip: Point; head: Point[] } | null {
  const dx = tx - cx;
  const dy = ty - cy;
  const dist = Math.hypot(dx, dy);
  if (dist <= radius * 1.1) return null;

  const ux = dx / dist;
  const uy = dy / dist;

  const start: Point = {
    x: cx + ux * radius,
    y: cy + uy * radius,
  };

  const headLength = Math.max(10, Math.min(radius * 0.65, strokeWidth * 5.2));
  const headHalfWidth = headLength * 0.42;

  const baseX = tx - ux * headLength;
  const baseY = ty - uy * headLength;

  const perpX = -uy;
  const perpY = ux;

  const head: Point[] = [
    { x: tx, y: ty },
    { x: baseX + perpX * headHalfWidth, y: baseY + perpY * headHalfWidth },
    { x: baseX - perpX * headHalfWidth, y: baseY - perpY * headHalfWidth },
  ];

  return { start, tip: { x: tx, y: ty }, head };
}

export function computeFontSize(label: string, radius: number, fontScale: number): number {
  const len = label.trim().length;
  const baseRatio = len <= 2 ? 0.94 : len === 3 ? 0.76 : 0.6;
  return Math.max(8, radius * baseRatio * fontScale);
}

export function pointsToSvgString(points: Point[]): string {
  return points.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
}

function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load page bitmap for export.'));
    img.src = src;
  });
}

function drawPolygon(ctx: CanvasRenderingContext2D, pts: Point[]) {
  if (pts.length === 0) return;
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  for (let i = 1; i < pts.length; i++) {
    ctx.lineTo(pts[i].x, pts[i].y);
  }
  ctx.closePath();
}

export interface RenderPageExportOptions {
  highResSourceCanvas?: HTMLCanvasElement;
  upscaleFactor?: number;
  darkenDrawing?: boolean;
}

const DARKEN_LUT = (() => {
  const lut = new Uint8Array(256);
  for (let v = 0; v < 256; v++) {
    if (v >= 246) {
      // Keep paper background spotless pure white
      lut[v] = 255;
    } else {
      // Strong CAD ink-darkening gamma curve: turns light gray hairlines & text crisp deep black
      const norm = v / 246;
      const curved = Math.pow(norm, 3.25) * 255;
      lut[v] = Math.max(0, Math.min(255, Math.round(curved)));
    }
  }
  return lut;
})();

/**
 * Enhances all drawing lines, dimensions, borders, and text to crisp dark ink
 * while keeping white paper spotless and preserving balloon/annotation colors (applied before overlays).
 */
function enhanceDrawingLinesAndText(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
): void {
  const imageData = ctx.getImageData(0, 0, width, height);
  const d = imageData.data;

  for (let i = 0; i < d.length; i += 4) {
    const r = d[i];
    const g = d[i + 1];
    const b = d[i + 2];

    const maxC = r >= g && r >= b ? r : g >= b ? g : b;
    const minC = r <= g && r <= b ? r : g <= b ? g : b;

    // Fast skip for pure white background pixels
    if (minC >= 246) {
      if (minC !== 255) {
        d[i] = 255;
        d[i + 1] = 255;
        d[i + 2] = 255;
      }
      continue;
    }

    const chroma = maxC - minC;
    if (chroma < 28) {
      // Grayscale / black CAD lines, hairlines, borders, and engineering text
      const lum = (r * 77 + g * 150 + b * 29) >> 8;
      const dark = DARKEN_LUT[lum];
      d[i] = dark;
      d[i + 1] = dark;
      d[i + 2] = dark;
    } else {
      // Colored CAD strokes/dimensions inside the base drawing: deepen saturation & darkness
      d[i] = Math.round(r * 0.72);
      d[i + 1] = Math.round(g * 0.72);
      d[i + 2] = Math.round(b * 0.72);
    }
  }

  ctx.putImageData(imageData, 0, 0);
}

export async function renderPageToCanvas(
  page: DrawingPage,
  balloons: BalloonItem[],
  annotations: DrawingAnnotation[],
  options?: RenderPageExportOptions
): Promise<HTMLCanvasElement> {
  const sourceEl: HTMLCanvasElement | HTMLImageElement =
    options?.highResSourceCanvas ?? (await loadImageElement(page.dataUrl));

  const rotated = page.rotation === 90 || page.rotation === 270;
  let scaleX = 1;
  let scaleY = 1;

  if (options?.highResSourceCanvas) {
    scaleX = options.highResSourceCanvas.width / Math.max(page.width, 1);
    scaleY = options.highResSourceCanvas.height / Math.max(page.height, 1);
  } else if (options?.upscaleFactor && options.upscaleFactor > 1) {
    scaleX = options.upscaleFactor;
    scaleY = options.upscaleFactor;
  }

  const scaledW = Math.round(page.width * scaleX);
  const scaledH = Math.round(page.height * scaleY);
  const outWidth = rotated ? scaledH : scaledW;
  const outHeight = rotated ? scaledW : scaledH;

  const canvas = document.createElement('canvas');
  canvas.width = outWidth;
  canvas.height = outHeight;
  const ctx = canvas.getContext('2d', { willReadFrequently: Boolean(options?.darkenDrawing) });
  if (!ctx) throw new Error('Failed to initialize export canvas.');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, outWidth, outHeight);

  // 1. Draw the base engineering drawing rotated into output space
  ctx.save();
  if (page.rotation === 90) {
    ctx.translate(outWidth, 0);
    ctx.rotate(Math.PI / 2);
  } else if (page.rotation === 180) {
    ctx.translate(outWidth, outHeight);
    ctx.rotate(Math.PI);
  } else if (page.rotation === 270) {
    ctx.translate(0, outHeight);
    ctx.rotate(-Math.PI / 2);
  }
  ctx.scale(scaleX, scaleY);
  ctx.drawImage(sourceEl, 0, 0, page.width, page.height);
  ctx.restore();

  // 2. Darken all lines & text on the base drawing before drawing colored balloons & brand logo
  if (options?.darkenDrawing) {
    enhanceDrawingLinesAndText(ctx, outWidth, outHeight);
  }

  // 3. Draw crisp vector annotations and balloons at full export resolution
  ctx.save();
  if (page.rotation === 90) {
    ctx.translate(outWidth, 0);
    ctx.rotate(Math.PI / 2);
  } else if (page.rotation === 180) {
    ctx.translate(outWidth, outHeight);
    ctx.rotate(Math.PI);
  } else if (page.rotation === 270) {
    ctx.translate(0, outHeight);
    ctx.rotate(-Math.PI / 2);
  }
  ctx.scale(scaleX, scaleY);

  // Draw annotations (boxes first, then stamps)
  for (const ann of annotations) {
    if (ann.kind === 'box') {
      ctx.save();
      ctx.strokeStyle = ann.color;
      ctx.lineWidth = ann.strokeWidth;
      if (ann.dashed) {
        ctx.setLineDash([ann.strokeWidth * 3, ann.strokeWidth * 2]);
      }
      ctx.strokeRect(ann.x, ann.y, ann.width, ann.height);
      if (ann.label.trim()) {
        ctx.setLineDash([]);
        ctx.font = `600 ${Math.max(12, Math.round(ann.strokeWidth * 5))}px "JetBrains Mono", monospace`;
        const metrics = ctx.measureText(ann.label);
        const padX = 6;
        const boxH = Math.max(18, Math.round(ann.strokeWidth * 7));
        ctx.fillStyle = ann.color;
        ctx.fillRect(ann.x, ann.y - boxH, metrics.width + padX * 2, boxH);
        ctx.fillStyle = '#FFFFFF';
        ctx.textBaseline = 'middle';
        ctx.fillText(ann.label, ann.x + padX, ann.y - boxH / 2);
      }
      ctx.restore();
    }
  }

  for (const ann of annotations) {
    if (ann.kind === 'stamp') {
      ctx.save();
      const lines = ann.text.split('\n');
      const fontSize = ann.fontSize;
      ctx.font = `700 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
      const lineHeight = fontSize * 1.25;
      const maxWidth = Math.max(
        40,
        ...lines.map((line) => ctx.measureText(line).width)
      );
      const padX = fontSize * 0.55;
      const padY = fontSize * 0.35;
      const boxW = maxWidth + padX * 2;
      const boxH = lines.length * lineHeight + padY * 2;

      if (ann.bordered) {
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        ctx.fillRect(ann.x, ann.y, boxW, boxH);
        ctx.strokeStyle = ann.color;
        ctx.lineWidth = Math.max(2, fontSize * 0.1);
        ctx.strokeRect(ann.x, ann.y, boxW, boxH);
      }

      ctx.fillStyle = ann.color;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      lines.forEach((line, idx) => {
        ctx.fillText(
          line,
          ann.x + boxW / 2,
          ann.y + padY + lineHeight * (idx + 0.5)
        );
      });
      ctx.restore();
    }
  }

  // Draw balloons
  for (const b of balloons) {
    const { x, y, targetX, targetY, style, label, subLabel } = b;
    const r = style.radius;
    const isCircleLike = style.shape === 'circle' || style.shape === 'split';
    const outerR = r + style.strokeWidth / 2;
    const innerR = Math.max(2, r - style.strokeWidth / 2);
    const teardrop =
      isCircleLike && style.pointerStyle === 'wedge'
        ? getTangentTeardropGeometry(x, y, targetX, targetY, outerR)
        : null;

    ctx.save();

    if (teardrop) {
      // Seamless tangent teardrop pin (outer tangent hull + circular inner cutout)
      ctx.beginPath();
      ctx.moveTo(teardrop.tip.x, teardrop.tip.y);
      ctx.lineTo(teardrop.t1.x, teardrop.t1.y);
      ctx.arc(x, y, outerR, teardrop.startAngle, teardrop.endAngle, false);
      ctx.closePath();

      if (style.transparentFill) {
        // Cut out inner circle with evenodd rule for true transparency
        ctx.moveTo(x + innerR, y);
        ctx.arc(x, y, innerR, 0, Math.PI * 2, true);
        ctx.fillStyle = style.color;
        ctx.fill('evenodd');
      } else {
        ctx.fillStyle = style.color;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(x, y, innerR, 0, Math.PI * 2);
        ctx.fillStyle = style.fillColor;
        ctx.fill();
      }

      if (style.shape === 'split') {
        ctx.strokeStyle = style.color;
        ctx.lineWidth = style.strokeWidth;
        ctx.beginPath();
        ctx.moveTo(x - innerR, y);
        ctx.lineTo(x + innerR, y);
        ctx.stroke();
      }
    } else {
      // Standard pointer (polygon wedge for non-circle shapes, or leader arrow)
      if (style.pointerStyle === 'wedge') {
        const wedge = getWedgePoints(x, y, targetX, targetY, r);
        if (wedge) {
          drawPolygon(ctx, wedge);
          ctx.fillStyle = style.color;
          ctx.fill();
        }
      } else if (style.pointerStyle === 'arrow') {
        const arrow = getLeaderArrowGeometry(x, y, targetX, targetY, r, style.strokeWidth);
        if (arrow) {
          ctx.strokeStyle = style.color;
          ctx.lineWidth = style.strokeWidth;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(arrow.start.x, arrow.start.y);
          ctx.lineTo(arrow.tip.x, arrow.tip.y);
          ctx.stroke();

          drawPolygon(ctx, arrow.head);
          ctx.fillStyle = style.color;
          ctx.fill();
        }
      }

      // Balloon body
      ctx.strokeStyle = style.color;
      ctx.lineWidth = style.strokeWidth;
      ctx.fillStyle = style.transparentFill ? 'rgba(255,255,255,0)' : style.fillColor;

      if (isCircleLike) {
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        if (!style.transparentFill) ctx.fill();
        ctx.stroke();

        if (style.shape === 'split') {
          ctx.beginPath();
          ctx.moveTo(x - r, y);
          ctx.lineTo(x + r, y);
          ctx.stroke();
        }
      } else {
        const pts = getShapePolygonPoints(style.shape, x, y, r);
        drawPolygon(ctx, pts);
        if (!style.transparentFill) ctx.fill();
        ctx.stroke();
      }
    }

    // Label text
    ctx.fillStyle = style.color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    if (style.shape === 'split') {
      const topFont = Math.max(8, r * 0.62 * style.fontScale);
      const bottomFont = Math.max(7, r * 0.48 * style.fontScale);
      ctx.font = `700 ${topFont}px "JetBrains Mono", monospace`;
      ctx.fillText(label, x, y - r * 0.36);
      ctx.font = `600 ${bottomFont}px "JetBrains Mono", monospace`;
      ctx.fillText(subLabel || '-', x, y + r * 0.4);
    } else {
      const fontSize = computeFontSize(label, r, style.fontScale);
      ctx.font = `700 ${fontSize}px "JetBrains Mono", monospace`;
      ctx.fillText(label, x, y + fontSize * 0.04);
    }

    ctx.restore();
  }

  ctx.restore();

  // Solid vector logo + 'BY DRAFT PRO MANUFACTURING SUITE' on transparent background at very bottom-left edge
  const stamp = getDrawingBrandStampMetrics(outWidth, outHeight);
  ctx.save();
  const logoX = stamp.marginX;
  const logoY = Math.max(2, outHeight - stamp.marginY - stamp.logoSize);
  drawBrandLogoOnCanvas(ctx, logoX, logoY, stamp.logoSize);

  ctx.font = `700 ${stamp.fontSize}px "Plus Jakarta Sans", "DM Sans", sans-serif`;
  ctx.fillStyle = '#0F172A';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(
    DRAWING_BRAND_STAMP_TEXT,
    logoX + stamp.logoSize + stamp.gap,
    logoY + stamp.logoSize / 2 + stamp.fontSize * 0.03
  );
  ctx.restore();

  return canvas;
}
