import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import * as UTIF from 'utif';
import type { DrawingPage, LoadedDocument } from '../types/drawing';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

export const SAMPLE_DRAWING_URL =
  '/assets/aistudio/50137K0YLDJ02H1______STAY_HORN_____________________K0YLF0021_RELEASE.pdf-__1__72e2aea2.pdf';
export const SAMPLE_DRAWING_NAME = 'STAY_HORN_50137-K0YL-DJ00-H1.pdf';

const MAX_RENDER_DIM = 3600;

function detectFileKind(fileName: string, mimeType: string): 'pdf' | 'tiff' | 'image' {
  const lower = fileName.toLowerCase();
  if (lower.endsWith('.pdf') || mimeType === 'application/pdf') {
    return 'pdf';
  }
  if (
    lower.endsWith('.tif') ||
    lower.endsWith('.tiff') ||
    mimeType === 'image/tiff' ||
    mimeType === 'image/x-tiff'
  ) {
    return 'tiff';
  }
  return 'image';
}

async function decodePDFBuffer(bytes: Uint8Array): Promise<DrawingPage[]> {
  // Pass a slice because pdfjs-dist transfers/detaches the underlying ArrayBuffer to its worker
  const loadingTask = pdfjsLib.getDocument({ data: bytes.slice() });
  const pdf = await loadingTask.promise;
  const pages: DrawingPage[] = [];

  try {
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const baseViewport = page.getViewport({ scale: 1 });
      const desiredScale = 2.6;
      const maxScale = Math.min(
        MAX_RENDER_DIM / Math.max(baseViewport.width, 1),
        MAX_RENDER_DIM / Math.max(baseViewport.height, 1)
      );
      const scale = Math.max(1, Math.min(desiredScale, maxScale));
      const viewport = page.getViewport({ scale });

      const canvas = document.createElement('canvas');
      canvas.width = Math.round(viewport.width);
      canvas.height = Math.round(viewport.height);
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Unable to create 2D rendering context for PDF page.');

      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      await page.render({ canvasContext: ctx, viewport, canvas, intent: 'print' }).promise;

      pages.push({
        index: pageNum - 1,
        dataUrl: canvas.toDataURL('image/png'),
        width: canvas.width,
        height: canvas.height,
        rotation: 0,
      });
    }
  } finally {
    await loadingTask.destroy();
  }

  return pages;
}

export interface HighResPDFPageResult {
  canvas: HTMLCanvasElement;
  ptWidth: number;
  ptHeight: number;
}

/**
 * Re-renders a specific page from the original PDF bytes at maximum print-grade
 * resolution (up to 5600px / 26MP) using pdf.js print intent for razor-sharp CAD exports.
 */
export async function renderPDFPageHighRes(
  pdfBytes: Uint8Array,
  pageIndex: number,
  maxDim = 5600,
  maxPixels = 26_000_000
): Promise<HighResPDFPageResult> {
  const loadingTask = pdfjsLib.getDocument({ data: pdfBytes.slice() });
  const pdf = await loadingTask.promise;
  try {
    const page = await pdf.getPage(pageIndex + 1);
    const baseViewport = page.getViewport({ scale: 1 });
    const baseW = Math.max(baseViewport.width, 1);
    const baseH = Math.max(baseViewport.height, 1);

    const desiredScale = 5.0;
    const dimCapScale = Math.min(maxDim / baseW, maxDim / baseH);
    const areaCapScale = Math.sqrt(maxPixels / (baseW * baseH));
    const scale = Math.max(2, Math.min(desiredScale, dimCapScale, areaCapScale));
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Unable to create high-resolution PDF export canvas.');

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    await page.render({ canvasContext: ctx, viewport, canvas, intent: 'print' }).promise;

    return {
      canvas,
      ptWidth: baseViewport.width,
      ptHeight: baseViewport.height,
    };
  } finally {
    await loadingTask.destroy();
  }
}

function decodeTIFFBuffer(buffer: ArrayBuffer): DrawingPage[] {
  const ifds = UTIF.decode(buffer);
  if (!ifds || ifds.length === 0) {
    throw new Error('Could not decode any image frames from this TIFF file.');
  }

  const pages: DrawingPage[] = [];
  for (let i = 0; i < ifds.length; i++) {
    const ifd = ifds[i];
    UTIF.decodeImage(buffer, ifd);
    const rgba = UTIF.toRGBA8(ifd);
    const width = ifd.width;
    const height = ifd.height;
    if (!width || !height) continue;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Unable to create 2D rendering context for TIFF page.');

    const imageData = ctx.createImageData(width, height);
    imageData.data.set(rgba);
    ctx.putImageData(imageData, 0, 0);

    pages.push({
      index: pages.length,
      dataUrl: canvas.toDataURL('image/png'),
      width,
      height,
      rotation: 0,
    });
  }

  if (pages.length === 0) {
    throw new Error('TIFF file contained no valid image dimensions.');
  }
  return pages;
}

function decodeImageFile(file: Blob): Promise<DrawingPage[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      const img = new Image();
      img.onload = () => {
        resolve([
          {
            index: 0,
            dataUrl,
            width: img.naturalWidth || img.width,
            height: img.naturalHeight || img.height,
            rotation: 0,
          },
        ]);
      };
      img.onerror = () => reject(new Error('Unsupported or corrupted image file.'));
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}

export async function loadDrawingFile(file: File): Promise<LoadedDocument> {
  const fileType = detectFileKind(file.name, file.type);

  if (fileType === 'pdf') {
    const buffer = await file.arrayBuffer();
    const sourcePdfBytes = new Uint8Array(buffer);
    const pages = await decodePDFBuffer(sourcePdfBytes);
    return { fileName: file.name, fileType: 'pdf', pages, sourcePdfBytes };
  }

  if (fileType === 'tiff') {
    const buffer = await file.arrayBuffer();
    const pages = decodeTIFFBuffer(buffer);
    return { fileName: file.name, fileType: 'tiff', pages };
  }

  const pages = await decodeImageFile(file);
  return { fileName: file.name, fileType: 'image', pages };
}

export async function loadSampleDrawing(): Promise<LoadedDocument> {
  const response = await fetch(SAMPLE_DRAWING_URL);
  if (!response.ok) {
    throw new Error('Sample drawing PDF could not be fetched.');
  }
  const buffer = await response.arrayBuffer();
  const sourcePdfBytes = new Uint8Array(buffer);
  const pages = await decodePDFBuffer(sourcePdfBytes);
  return {
    fileName: SAMPLE_DRAWING_NAME,
    fileType: 'pdf',
    pages,
    sourcePdfBytes,
  };
}

export function computeProportionalRadius(width: number, height: number): number {
  const base = Math.min(width, height);
  const scaled = Math.round(base * 0.0155);
  return Math.max(14, Math.min(34, scaled));
}
