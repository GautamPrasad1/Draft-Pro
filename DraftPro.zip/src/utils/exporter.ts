import { jsPDF } from 'jspdf';
import {
  DEFAULT_REPORT_META,
  type BalloonItem,
  type BalloonStyle,
  type DrawingAnnotation,
  type InspectionReportMeta,
  type LoadedDocument,
  type ProjectJSON,
} from '../types/drawing';
import { renderPageToCanvas } from './balloonGeometry';
import { renderPDFPageHighRes } from './fileLoader';
import {
  exportInspectionSheetPDF,
  exportInspectionSheetXLSX,
} from './inspectionSheetExport';

export { exportInspectionSheetPDF, exportInspectionSheetXLSX };

function stripExtension(name: string): string {
  return name.replace(/\.[^/.]+$/, '');
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function computeImageUpscaleFactor(width: number, height: number): number {
  const maxDim = Math.max(width, height, 1);
  const targetMaxDim = 4800;
  const maxPixels = 24_000_000;
  if (maxDim >= targetMaxDim) return 1;
  const dimFactor = targetMaxDim / maxDim;
  const areaFactor = Math.sqrt(maxPixels / Math.max(width * height, 1));
  return Math.max(1, Math.min(2.5, dimFactor, areaFactor));
}

export async function exportPageAsPNG(
  doc: LoadedDocument,
  pageIndex: number,
  balloons: BalloonItem[],
  annotations: DrawingAnnotation[]
): Promise<void> {
  const page = doc.pages[pageIndex];
  if (!page) return;

  const pageBalloons = balloons.filter((b) => b.pageIndex === pageIndex);
  const pageAnnotations = annotations.filter((a) => a.pageIndex === pageIndex);

  let canvas: HTMLCanvasElement;
  if (doc.fileType === 'pdf' && doc.sourcePdfBytes) {
    const highRes = await renderPDFPageHighRes(doc.sourcePdfBytes, pageIndex);
    canvas = await renderPageToCanvas(page, pageBalloons, pageAnnotations, {
      highResSourceCanvas: highRes.canvas,
      darkenDrawing: true,
    });
  } else {
    canvas = await renderPageToCanvas(page, pageBalloons, pageAnnotations, {
      upscaleFactor: computeImageUpscaleFactor(page.width, page.height),
      darkenDrawing: true,
    });
  }

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/png')
  );
  if (!blob) throw new Error('Could not encode PNG output.');

  const suffix = doc.pages.length > 1 ? `_p${pageIndex + 1}` : '';
  triggerDownload(blob, `${stripExtension(doc.fileName)}_ballooned${suffix}.png`);
}

export async function exportAnnotatedPDF(
  doc: LoadedDocument,
  balloons: BalloonItem[],
  annotations: DrawingAnnotation[]
): Promise<void> {
  let pdf: jsPDF | null = null;

  for (let i = 0; i < doc.pages.length; i++) {
    const page = doc.pages[i];
    const pageBalloons = balloons.filter((b) => b.pageIndex === i);
    const pageAnnotations = annotations.filter((a) => a.pageIndex === i);
    const rotated = page.rotation === 90 || page.rotation === 270;

    let canvas: HTMLCanvasElement;
    let pdfW: number;
    let pdfH: number;

    if (doc.fileType === 'pdf' && doc.sourcePdfBytes) {
      const highRes = await renderPDFPageHighRes(doc.sourcePdfBytes, i);
      canvas = await renderPageToCanvas(page, pageBalloons, pageAnnotations, {
        highResSourceCanvas: highRes.canvas,
        darkenDrawing: true,
      });
      // Preserve exact original physical PDF page size in points (e.g. A4/A3/A2) with 350-450 DPI lossless PNG inside
      pdfW = rotated ? highRes.ptHeight : highRes.ptWidth;
      pdfH = rotated ? highRes.ptWidth : highRes.ptHeight;
    } else {
      canvas = await renderPageToCanvas(page, pageBalloons, pageAnnotations, {
        upscaleFactor: computeImageUpscaleFactor(page.width, page.height),
        darkenDrawing: true,
      });
      // Map raster image to crisp 300-DPI physical PDF points
      pdfW = (canvas.width / 300) * 72;
      pdfH = (canvas.height / 300) * 72;
    }

    const orientation = pdfW >= pdfH ? 'landscape' : 'portrait';
    const format: [number, number] = [pdfW, pdfH];

    if (!pdf) {
      pdf = new jsPDF({
        orientation,
        unit: 'pt',
        format,
        compress: true,
      });
    } else {
      pdf.addPage(format, orientation);
    }

    // Lossless PNG keeps 1px CAD lines, dimension text, and vector balloons razor-sharp with zero JPEG blur
    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, pdfW, pdfH, undefined, 'FAST');
  }

  if (pdf) {
    pdf.save(`${stripExtension(doc.fileName)}_ballooned.pdf`);
  }
}

export function exportProjectJSON(
  fileName: string,
  balloons: BalloonItem[],
  annotations: DrawingAnnotation[],
  nextNumber: number,
  defaultStyle: BalloonStyle,
  reportMeta: InspectionReportMeta
): void {
  const payload: ProjectJSON = {
    version: 1,
    fileName,
    balloons,
    annotations,
    nextNumber,
    defaultStyle,
    reportMeta,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: 'application/json',
  });
  triggerDownload(blob, `${stripExtension(fileName)}.balloon.json`);
}

export function parseProjectJSON(raw: string): ProjectJSON {
  const data = JSON.parse(raw) as Partial<ProjectJSON>;
  if (!Array.isArray(data.balloons) || !Array.isArray(data.annotations)) {
    throw new Error('Invalid Draft Pro project file.');
  }
  const normalizedBalloons: BalloonItem[] = data.balloons.map((b) => ({
    ...b,
    description: typeof b.description === 'string' ? b.description : '',
    inspectionMethod:
      typeof b.inspectionMethod === 'string' ? b.inspectionMethod : '',
    samples:
      Array.isArray(b.samples) && b.samples.length === 5
        ? (b.samples as [string, string, string, string, string])
        : ['', '', '', '', ''],
    status: b.status === 'OK' || b.status === 'NOT OK' ? b.status : '',
  }));

  return {
    version: 1,
    fileName: typeof data.fileName === 'string' ? data.fileName : 'drawing',
    balloons: normalizedBalloons,
    annotations: data.annotations,
    nextNumber:
      typeof data.nextNumber === 'number'
        ? data.nextNumber
        : normalizedBalloons.length + 1,
    defaultStyle: data.defaultStyle as BalloonStyle,
    reportMeta: data.reportMeta
      ? { ...DEFAULT_REPORT_META, ...data.reportMeta }
      : { ...DEFAULT_REPORT_META },
  };
}
